#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base64 -w0 Ironframe.keystore > ANDROID_KEYSTORE_BASE64.txt
printf "Wrote ANDROID_KEYSTORE_BASE64.txt\n"
