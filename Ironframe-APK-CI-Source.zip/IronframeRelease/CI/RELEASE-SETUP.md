# Ironframe — GitHub Release Pipeline Setup

This repo uses GitHub Actions + GameCI. After one-time setup, each successful push to `main`, manual workflow run, or version-tag build creates a signed arm64 APK and AAB, calculates SHA-256 hashes, and attaches the files to a GitHub Release. Main/manual builds receive version `0.1.<GitHub run number>`; a version tag such as `v0.2.0` keeps that exact version. After the first successful cloud build, the permanent latest-release links are:

- `https://github.com/OWNER/Ironframe/releases/latest/download/Ironframe.apk`
- `https://github.com/OWNER/Ironframe/releases/latest/download/Ironframe.aab`

Replace `OWNER` with the GitHub account or organization that owns the repository.

## Required one-time GitHub Actions secrets

Open **Repository → Settings → Secrets and variables → Actions → New repository secret**. Never commit the release keystore, license file, passwords, or these secrets into the repository.

| Secret | Value |
|---|---|
| `UNITY_LICENSE` | Entire contents of an authorized Unity license `.ulf` file for the Unity account used by CI. |
| `UNITY_EMAIL` | Email for that Unity account. |
| `UNITY_PASSWORD` | Password for that Unity account. Store only as a GitHub Actions secret. |
| `ANDROID_KEYSTORE_BASE64` | Single-line base64 contents of `Ironframe.keystore`; the separate signing kit includes this text file. |
| `ANDROID_KEYSTORE_PASS` | Keystore password from the separate signing kit. |
| `ANDROID_KEYALIAS_NAME` | `ironframe-release` |
| `ANDROID_KEYALIAS_PASS` | Alias password from the separate signing kit (same as store password in this kit). |

GameCI's Personal-license path requires an authorized Unity license and credentials in repository secrets; it is not a license bypass. If you do not already have a valid `.ulf`, use Unity Hub's licensing flow to acquire/activate a license and copy its file contents into the `UNITY_LICENSE` secret. The pipeline cannot legally build without an authorized license.

## Run the first build

1. Connect GitHub to ChatGPT if you want help publishing the repository into your account; otherwise upload/push the contents of this folder to a repo named `Ironframe`.
2. Add all seven secrets listed above.
3. Push the source to `main`, or open **Actions → Ironframe Android Release → Run workflow**. Once the APK and AAB builds pass, CI publishes them with `SHA256SUMS.txt` as a GitHub Release.
4. Future pushes to `main` publish `0.1.<run number>` releases automatically. For deliberate semantic releases, push a tag such as `v0.2.0`; CI publishes that exact version. Each release includes versioned files and stable `Ironframe.apk` / `Ironframe.aab` names.

## Signing-key custody

The keystore is a long-term app identity. Store it in at least two secure backups, restrict access, and never regenerate it after publishing unless you intentionally change app identity. The signing kit is separate from the source archive; do not add it to Git or a public issue. Google Play App Signing is recommended for Play Store deployment; this key can be used as the upload key if Play App Signing is enabled.

## Build expectations

Unity version: `6000.3.24f1` (Unity 6.3 LTS), URP `17.3.0`; min Android API 29; target Android API 36; ARM64; IL2CPP; Vulkan primary and OpenGL ES fallback. `UnityBuild` and Android SDK downloads occur in the cloud runner. The runner needs enough free disk space for two Unity Android builds.

No release is published if either build fails. The workflow validates archive integrity and SHA-256, but APK installation, runtime smoke tests, local Wi-Fi/hotspot sessions, Play Console validation and Snapdragon 685 profiling still require a real device. The CI does not create fake profiler captures or fabricated test results.
