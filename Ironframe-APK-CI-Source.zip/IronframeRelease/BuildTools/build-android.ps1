param(
    [ValidateSet('dev-apk','release-apk','release-aab')]
    [string]$Kind = 'dev-apk'
)
$ErrorActionPreference = 'Stop'
$ProjectDir = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Unity = $env:UNITY_BIN
if ([string]::IsNullOrWhiteSpace($Unity) -or -not (Test-Path $Unity)) {
    throw 'Set UNITY_BIN to the full path of Unity.exe for your Unity 6.3 LTS installation.'
}
New-Item -ItemType Directory -Force -Path (Join-Path $ProjectDir 'Logs') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $ProjectDir 'Builds/Android') | Out-Null
switch ($Kind) {
    'dev-apk' { $Method = 'Ironframe.Editor.IronframeProjectSetup.BatchSetupAndBuildDevelopmentApk'; $Default = Join-Path $ProjectDir 'Builds/Android/Ironframe-dev.apk' }
    'release-apk' { $Method = 'Ironframe.Editor.IronframeProjectSetup.BatchBuildReleaseApk'; $Default = Join-Path $ProjectDir 'Builds/Android/Ironframe-release.apk' }
    'release-aab' { $Method = 'Ironframe.Editor.IronframeProjectSetup.BatchBuildReleaseAab'; $Default = Join-Path $ProjectDir 'Builds/Android/Ironframe-release.aab' }
}
if ([string]::IsNullOrWhiteSpace($env:IRONFRAME_OUTPUT)) { $env:IRONFRAME_OUTPUT = $Default }
$LogPath = Join-Path $ProjectDir 'Logs/ironframe-build.log'
& $Unity -batchmode -quit -projectPath $ProjectDir -buildTarget Android -executeMethod $Method -logFile $LogPath
if ($LASTEXITCODE -ne 0) { throw "Unity build failed with exit code $LASTEXITCODE. See $LogPath" }
if (-not (Test-Path $env:IRONFRAME_OUTPUT)) { throw "No build output found at $env:IRONFRAME_OUTPUT. See $LogPath" }
Get-FileHash $env:IRONFRAME_OUTPUT -Algorithm SHA256 | Format-List
Write-Host "Build created: $env:IRONFRAME_OUTPUT"
