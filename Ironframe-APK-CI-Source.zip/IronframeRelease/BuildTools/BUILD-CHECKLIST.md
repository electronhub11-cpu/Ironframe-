# Ironframe build and validation record

Do not mark any box based on intended settings alone. Archive actual logs and capture the profiler on a physical Android device.

## Environment and build
- [ ] Project opens without Package Manager errors
- [ ] Unity Editor exact version and host OS recorded
- [ ] Android Build Support, SDK/NDK, OpenJDK and IL2CPP modules confirmed
- [ ] URP asset and materials generated; no magenta objects
- [ ] Android development APK build passed
- [ ] Release APK build passed with the final release signing key
- [ ] Release AAB build passed with the same signing identity
- [ ] APK SHA-256 and Unity Editor.log archived

## Target device
- Device model / SoC / GPU:
- Android version / API:
- Build SHA-256:
- Cold launch time:
- Vulkan launch result:
- OpenGL ES 3.2 fallback result:
- Portrait rotation blocked / landscape retained:
- 30-minute soak / thermal result:
- Crash / ANR observation:

## Gameplay and networking
- [ ] Movement, rotation, brakes/friction and terrain collision
- [ ] Turret traverse and gun elevation
- [ ] Ballistic projectile arc and collision
- [ ] Penetrating hit and blocked hit
- [ ] Engine/turret damage and destruction
- [ ] AI targeting and firing
- [ ] Garage add/remove/armor/snap controls
- [ ] Save/load blueprint across app restart
- [ ] Mode cycle (test range, sandbox, mission)
- [ ] Two devices on the same Wi-Fi network
- [ ] Two devices on a phone hotspot
- [ ] Host disconnect / client timeout / reconnect behavior
- [ ] Session capacity (one host + three clients)

## Profiler evidence (physical device only)
- Median FPS / 1% low FPS:
- CPU frame time median / p95:
- GPU frame time median / p95:
- Managed GC allocation per frame:
- Peak Unity allocated / reserved memory:
- Draw calls / batches:
- Visible triangles:
- Profiler capture paths:
- Thermal throttling after 15 minutes:
- Known issues:

## Current measured status
The source-only delivery has not been compiled by Unity or profiled on a phone in the available environment. No device metrics should be entered until a real test is completed.
