#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
UNITY_BIN="${UNITY_BIN:-}"
OUTPUT_KIND="${1:-dev-apk}"
mkdir -p "$PROJECT_DIR/Logs" "$PROJECT_DIR/Builds/Android"

if [[ -z "$UNITY_BIN" ]]; then
  echo "Set UNITY_BIN to the full path of Unity 6.3 LTS (for example /opt/Unity/Editor/Unity)." >&2
  exit 2
fi
if [[ ! -x "$UNITY_BIN" ]]; then
  echo "Unity executable not found or not executable: $UNITY_BIN" >&2
  exit 2
fi

case "$OUTPUT_KIND" in
  dev-apk)
    export IRONFRAME_OUTPUT="${IRONFRAME_OUTPUT:-$PROJECT_DIR/Builds/Android/Ironframe-dev.apk}"
    METHOD="Ironframe.Editor.IronframeProjectSetup.BatchSetupAndBuildDevelopmentApk"
    ;;
  release-apk)
    export IRONFRAME_OUTPUT="${IRONFRAME_OUTPUT:-$PROJECT_DIR/Builds/Android/Ironframe-release.apk}"
    METHOD="Ironframe.Editor.IronframeProjectSetup.BatchBuildReleaseApk"
    ;;
  release-aab)
    export IRONFRAME_OUTPUT="${IRONFRAME_OUTPUT:-$PROJECT_DIR/Builds/Android/Ironframe-release.aab}"
    METHOD="Ironframe.Editor.IronframeProjectSetup.BatchBuildReleaseAab"
    ;;
  *)
    echo "Usage: $0 {dev-apk|release-apk|release-aab}" >&2
    exit 2
    ;;
esac

if "$UNITY_BIN" -batchmode -quit -projectPath "$PROJECT_DIR" -buildTarget Android -executeMethod "$METHOD" -logFile "$PROJECT_DIR/Logs/ironframe-build.log"; then
  STATUS=0
else
  STATUS=$?
fi
if [[ $STATUS -ne 0 ]]; then
  echo "Unity returned exit code $STATUS. See $PROJECT_DIR/Logs/ironframe-build.log" >&2
  exit "$STATUS"
fi
if [[ ! -f "$IRONFRAME_OUTPUT" ]]; then
  echo "Unity exited without creating the expected output: $IRONFRAME_OUTPUT" >&2
  echo "Inspect Logs/ironframe-build.log and confirm Android modules/signing are installed." >&2
  exit 3
fi
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum "$IRONFRAME_OUTPUT"
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 "$IRONFRAME_OUTPUT"
else
  echo "Build created, but no SHA-256 utility (sha256sum/shasum) was found." >&2
fi
echo "Build created: $IRONFRAME_OUTPUT"
