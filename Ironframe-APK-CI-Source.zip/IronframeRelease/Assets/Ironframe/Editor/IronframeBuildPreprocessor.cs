#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Ironframe.Editor
{
    public sealed class IronframeBuildPreprocessor : IPreprocessBuildWithReport
    {
        public int callbackOrder => -1000;

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report.summary.platform != BuildTarget.Android) return;
            IronframeProjectSetup.PrepareForBuild();
            if (!AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/Ironframe/Scenes/Ironframe_Prototype.unity"))
                IronframeProjectSetup.CreatePrototypeScene();
            Debug.Log("Ironframe: Android pre-build check completed. Ensure configured keystore secrets were supplied by CI.");
        }
    }
}
#endif
