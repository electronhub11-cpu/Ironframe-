#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Ironframe.Editor
{
    public static class IronframeProjectSetup
    {
        private const string Root = "Assets/Ironframe";
        private const string ScenePath = Root + "/Scenes/Ironframe_Prototype.unity";
        private const string PipelinePath = Root + "/Settings/Ironframe_URP.asset";
        private const string TankPrefabPath = Root + "/Prefabs/IF_ModularTank.prefab";

        [MenuItem("Ironframe/Setup Android Project Defaults")]
        public static void SetupAndroidDefaults()
        {
            ApplyAndroidPlayerSettings();
            EnsureFolders();
            EnsureUrpAsset();
            EnsureMaterials();
            EnsureTankPrefab();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("Ironframe Android defaults applied (API 29+, ARM64/IL2CPP, Vulkan then GLES 3.2, landscape, LAN permission).");
        }

        /// <summary>Prepare settings/assets before a CI Android build. The startup scene is committed in source.</summary>
        public static void PrepareForBuild()
        {
            ApplyAndroidPlayerSettings();
            EnsureFolders();
            EnsureUrpAsset();
            EnsureMaterials();
            EnsureTankPrefab();
            AssetDatabase.SaveAssets();
            Debug.Log("Ironframe: CI build preparation complete.");
        }

        private static void ApplyAndroidPlayerSettings()
        {
            PlayerSettings.companyName = "Ironframe Studio";
            PlayerSettings.productName = "Ironframe";
            PlayerSettings.applicationIdentifier = "com.ironframestudio.ironframe";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel29;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.runInBackground = true;
            PlayerSettings.gcIncremental = true;
            PlayerSettings.MTRendering = true;
            PlayerSettings.Android.forceInternetPermission = true;
            PlayerSettings.openGLRequireES32 = true;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.Vulkan, GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel36;
            PlayerSettings.Android.optimizedFramePacing = true;
            PlayerSettings.Android.blitType = AndroidBlitType.Auto;
            EditorUserBuildSettings.androidBuildSubtarget = MobileTextureSubtarget.ASTC;
            QualitySettings.vSyncCount = 0;
            QualitySettings.antiAliasing = 0;
            Time.fixedDeltaTime = 0.02f;
        }

        private static void EnsureFolders()
        {
            // Create parent folders before children. AssetDatabase.CreateFolder does not create
            // missing ancestors, so a fresh project must create Assets/Ironframe first.
            foreach (string folder in new[]
            {
                Root,
                Root + "/Scenes", Root + "/Settings", Root + "/Prefabs", Root + "/Art",
                Root + "/Art/Materials", Root + "/Scripts", Root + "/Editor",
                "Assets/Resources", "Assets/Resources/Ironframe", "Assets/Resources/Ironframe/Materials"
            })
            {
                if (AssetDatabase.IsValidFolder(folder)) continue;
                string parent = Path.GetDirectoryName(folder).Replace('\\', '/');
                string name = Path.GetFileName(folder);
                if (AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder(parent, name);
                else Debug.LogWarning("Ironframe could not create folder because its parent is missing: " + folder);
            }
        }

        private static void EnsureUrpAsset()
        {
            var asset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
            if (asset == null)
            {
                asset = UniversalRenderPipelineAsset.Create();
                AssetDatabase.CreateAsset(asset, PipelinePath);
                var rendererData = asset.LoadBuiltinRendererData(RendererType.UniversalRenderer);
                if (rendererData != null && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(rendererData)))
                    AssetDatabase.AddObjectToAsset(rendererData, asset);
            }
            asset.supportsHDR = false;
            asset.supportsDynamicBatching = true;
            asset.useSRPBatcher = true;
            asset.maxAdditionalLightsCount = 0;
            asset.renderScale = 1.0f;
            GraphicsSettings.defaultRenderPipeline = asset;
            QualitySettings.renderPipeline = asset;
            EditorUtility.SetDirty(asset);
        }


        private static void EnsureTankPrefab()
        {
            if (AssetDatabase.LoadAssetAtPath<GameObject>(TankPrefabPath) != null) return;
            var root = new GameObject("IF_ModularTank");
            var body = root.AddComponent<Rigidbody>();
            body.mass = 18000f;
            body.drag = 0.08f;
            body.angularDrag = 4.5f;
            body.useGravity = true;
            body.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
            var collider = root.AddComponent<BoxCollider>();
            collider.size = new Vector3(2.8f, 0.9f, 4f);
            root.AddComponent<Ironframe.TankBuildController>();
            root.AddComponent<Ironframe.TankDamage>();
            root.AddComponent<Ironframe.TankController>();
            bool success;
            PrefabUtility.SaveAsPrefabAsset(root, TankPrefabPath, out success);
            UnityEngine.Object.DestroyImmediate(root);
            if (!success) Debug.LogWarning("Ironframe: tank prefab generation failed; runtime TankFactory remains available.");
        }

        private static void EnsureMaterials()
        {
            string folder = "Assets/Resources/Ironframe/Materials";
            Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            CreateMaterial(folder + "/IF_Hull.mat", shader, new Color(0.25f, 0.32f, 0.27f));
            CreateMaterial(folder + "/IF_Turret.mat", shader, new Color(0.31f, 0.38f, 0.31f));
            CreateMaterial(folder + "/IF_Gun.mat", shader, new Color(0.15f, 0.18f, 0.16f));
            CreateMaterial(folder + "/IF_Track.mat", shader, new Color(0.105f, 0.12f, 0.11f));
            CreateMaterial(folder + "/IF_Wheel.mat", shader, new Color(0.16f, 0.18f, 0.16f));
            CreateMaterial(folder + "/IF_Armor.mat", shader, new Color(0.40f, 0.43f, 0.36f));
            CreateMaterial(folder + "/IF_Fuel.mat", shader, new Color(0.19f, 0.23f, 0.20f));
            CreateMaterial(folder + "/IF_Ground.mat", shader, new Color(0.24f, 0.28f, 0.24f));
            CreateMaterial(folder + "/IF_Cover.mat", shader, new Color(0.32f, 0.34f, 0.29f));
            CreateMaterial(folder + "/IF_Projectile.mat", shader, new Color(0.88f, 0.72f, 0.36f));
        }

        private static void CreateMaterial(string path, Shader shader, Color color)
        {
            var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (existing != null) return;
            var material = new Material(shader) { color = color, enableInstancing = true };
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", 0.18f);
            AssetDatabase.CreateAsset(material, path);
        }

        [MenuItem("Ironframe/Create Prototype Scene")]
        public static void CreatePrototypeScene()
        {
            EnsureFolders();
            EnsureUrpAsset();
            EnsureMaterials();
            EnsureTankPrefab();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("IronframeBootstrap");
            root.AddComponent<Ironframe.IronframeBootstrap>();
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("Created and registered " + ScenePath + ". The prototype scene creates the range, tank actors, camera, UI, and LAN manager at runtime.");
        }

        [MenuItem("Ironframe/Build/Build Android APK (Development)")]
        public static void BuildDevelopmentApk() { BuildAndroid(false, true, "Builds/Android/Ironframe-dev.apk"); }

        [MenuItem("Ironframe/Build/Build Android APK (Release)")]
        public static void BuildReleaseApk() { BuildAndroid(false, false, "Builds/Android/Ironframe-release.apk"); }

        [MenuItem("Ironframe/Build/Build Android AAB (Release)")]
        public static void BuildReleaseAab() { BuildAndroid(true, false, "Builds/Android/Ironframe-release.aab"); }

        // Batch entry points allow CI or a local script to build without clicking Editor menus.
        public static void BatchSetupAndBuildDevelopmentApk()
        {
            SetupAndroidDefaults();
            if (!File.Exists(ScenePath)) CreatePrototypeScene();
            BuildAndroid(false, true, Environment.GetEnvironmentVariable("IRONFRAME_OUTPUT") ?? "Builds/Android/Ironframe-dev.apk");
        }

        public static void BatchBuildReleaseApk()
        {
            SetupAndroidDefaults();
            if (!File.Exists(ScenePath)) CreatePrototypeScene();
            BuildAndroid(false, false, Environment.GetEnvironmentVariable("IRONFRAME_OUTPUT") ?? "Builds/Android/Ironframe-release.apk");
        }

        public static void BatchBuildReleaseAab()
        {
            SetupAndroidDefaults();
            if (!File.Exists(ScenePath)) CreatePrototypeScene();
            BuildAndroid(true, false, Environment.GetEnvironmentVariable("IRONFRAME_OUTPUT") ?? "Builds/Android/Ironframe-release.aab");
        }

        private static void BuildAndroid(bool appBundle, bool development, string outputPath)
        {
            SetupAndroidDefaults();
            if (EditorBuildSettings.scenes.Length == 0 || !File.Exists(ScenePath)) CreatePrototypeScene();
            if (!EditorUserBuildSettings.activeBuildTarget.Equals(BuildTarget.Android))
            {
                EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            }
            string outputDirectory = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrEmpty(outputDirectory)) Directory.CreateDirectory(outputDirectory);
            EditorUserBuildSettings.buildAppBundle = appBundle;
            var options = development ? BuildOptions.Development | BuildOptions.AllowDebugging : BuildOptions.None;
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = Array.ConvertAll(EditorBuildSettings.scenes, s => s.path),
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = options
            });
            Debug.Log($"Ironframe build result: {report.summary.result}; output={outputPath}; size={report.summary.totalSize}; errors={report.summary.totalErrors}; warnings={report.summary.totalWarnings}");
            if (report.summary.result != BuildResult.Succeeded)
                throw new Exception("Ironframe Android build failed. Check Editor.log and confirm Android SDK/NDK, OpenJDK, IL2CPP, URP and a valid release keystore are configured.");
        }
    }
}
#endif
