using UnityEngine;

namespace Ironframe
{
    /// <summary>Low-cost range target with simple cover checks and game-tuned combat logic.</summary>
    public sealed class TankAIController : MonoBehaviour
    {
        [SerializeField] private float preferredRange = 25f;
        [SerializeField] private float maximumEngagementRange = 65f;
        private TankController _controller;
        private TankController _target;
        private float _reacquireTimer;

        private void Awake() { _controller = GetComponent<TankController>(); }

        private void Update()
        {
            if (_controller == null || _controller.Damage == null || _controller.Damage.IsDestroyed) return;
            _reacquireTimer -= Time.deltaTime;
            if (_target == null || _target.Damage == null || _target.Damage.IsDestroyed || _reacquireTimer <= 0f)
            {
                _target = FindTarget();
                _reacquireTimer = 1.25f;
            }
            if (_target == null)
            {
                _controller.SetDriveInput(0f, 0f);
                _controller.SetFireHeld(false);
                return;
            }

            Vector3 delta = _target.transform.position - transform.position;
            float distance = delta.magnitude;
            _controller.AimAtWorldPoint(_target.transform.position + Vector3.up * 0.55f);
            Vector3 local = transform.InverseTransformDirection(delta.normalized);
            float headingError = Mathf.Atan2(local.x, local.z) * Mathf.Rad2Deg;
            float throttle = distance > preferredRange + 8f ? 0.55f : (distance < preferredRange - 5f ? -0.20f : 0f);
            float steer = Mathf.Clamp(headingError / 45f, -0.65f, 0.65f);
            if (distance < 12f) { throttle = 0.15f; steer = Mathf.Sign(headingError == 0f ? 1f : headingError) * 0.5f; }
            _controller.SetDriveInput(throttle, steer);

            float localYaw = Mathf.Abs(Mathf.DeltaAngle(_controller.TurretYaw, Mathf.Atan2(local.x, local.z) * Mathf.Rad2Deg));
            bool canFire = distance <= maximumEngagementRange && localYaw < 8f && HasLineOfSight();
            _controller.SetFireHeld(canFire);
        }

        private bool HasLineOfSight()
        {
            if (_target == null || _controller.Build == null || _controller.Build.Muzzle == null) return false;
            Vector3 origin = _controller.Build.Muzzle.position;
            Vector3 destination = _target.transform.position + Vector3.up * 0.35f;
            Vector3 delta = destination - origin;
            float distance = delta.magnitude;
            if (distance <= 0.1f) return true;
            if (!Physics.Raycast(origin, delta / distance, out RaycastHit hit, distance, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
                return false;
            return hit.collider.GetComponentInParent<TankController>() == _target;
        }

        private TankController FindTarget()
        {
            var all = FindObjectsOfType<TankController>();
            TankController best = null;
            float bestDistance = float.MaxValue;
            for (int i = 0; i < all.Length; i++)
            {
                var candidate = all[i];
                if (candidate == _controller || candidate.Damage == null || candidate.Damage.IsDestroyed || candidate.IsNetworkProxy) continue;
                if (candidate.IsLocalPlayer || (LanSessionManager.Instance != null && LanSessionManager.Instance.IsHost && LanSessionManager.Instance.IsRegisteredPlayer(candidate)))
                {
                    float d = (candidate.transform.position - transform.position).sqrMagnitude;
                    if (d < bestDistance) { best = candidate; bestDistance = d; }
                }
            }
            return best;
        }
    }
}
