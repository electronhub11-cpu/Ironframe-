using System;
using UnityEngine;

namespace Ironframe
{
    public sealed class TankDamage : MonoBehaviour
    {
        public const float MaximumHealth = 100f;
        [SerializeField] private float health = MaximumHealth;
        [SerializeField] private float engineCondition = 1f;
        [SerializeField] private float turretCondition = 1f;
        private TankBuildController _build;

        public float Health => health;
        public float EngineCondition => engineCondition;
        public float TurretCondition => turretCondition;
        public bool IsDestroyed => health <= 0f;
        public event Action<TankDamage> Destroyed;

        private void Awake() { _build = GetComponent<TankBuildController>(); }

        public void ApplyNetworkHealth(float networkHealth, bool destroyed)
        {
            bool wasDestroyed = IsDestroyed;
            health = Mathf.Clamp(networkHealth, 0f, MaximumHealth);
            if (destroyed) health = 0f;
            var body = GetComponent<Rigidbody>();
            var controller = GetComponent<TankController>();
            bool proxy = controller != null && controller.IsNetworkProxy;
            var rootCollider = GetComponent<Collider>();
            if (health <= 0f)
            {
                if (body != null) { body.velocity = Vector3.zero; body.isKinematic = true; }
                foreach (var c in GetComponentsInChildren<Collider>()) c.enabled = false;
            }
            else if (wasDestroyed)
            {
                if (body != null) body.isKinematic = proxy;
                if (rootCollider != null) rootCollider.enabled = !proxy;
            }
            if (!wasDestroyed && health <= 0f) Destroyed?.Invoke(this);
        }

        public void ResetDamage()
        {
            health = MaximumHealth;
            engineCondition = 1f;
            turretCondition = 1f;
            var controller = GetComponent<TankController>();
            bool proxy = controller != null && controller.IsNetworkProxy;
            var rootCollider = GetComponent<Collider>();
            if (rootCollider != null) rootCollider.enabled = !proxy;
            var body = GetComponent<Rigidbody>();
            if (body != null && !proxy) body.isKinematic = false;
        }

        public void ApplyProjectileHit(Vector3 impact, Vector3 incomingDirection, float projectileSpeed, float caliberMm, float baseDamage, GameObject attacker)
        {
            if (IsDestroyed) return;
            if (_build == null) _build = GetComponent<TankBuildController>();
            float armor = _build != null ? _build.ArmorAtWorldPoint(impact) : 40f;
            float penetration = TankBuildController.EstimatePenetrationMm(projectileSpeed, caliberMm);
            Vector3 local = transform.InverseTransformPoint(impact);
            if (penetration < armor)
            {
                health = Mathf.Max(1f, health - baseDamage * 0.06f);
                return;
            }

            float angleFactor = Vector3.Angle(-incomingDirection.normalized, transform.forward);
            // Angles are gameplay-tuned: shallow impacts still do reduced damage.
            float damageFactor = angleFactor > 62f ? 0.62f : 1f;
            health = Mathf.Max(0f, health - baseDamage * damageFactor);
            if (local.z < -0.65f && UnityEngine.Random.value < 0.55f) engineCondition = Mathf.Max(0f, engineCondition - 0.35f);
            else if (local.y > 0.55f && UnityEngine.Random.value < 0.45f) turretCondition = Mathf.Max(0f, turretCondition - 0.35f);

            if (health <= 0f)
            {
                var body = GetComponent<Rigidbody>();
                if (body != null) { body.velocity = Vector3.zero; body.angularVelocity = Vector3.zero; body.isKinematic = true; }
                foreach (var c in GetComponentsInChildren<Collider>()) c.enabled = false;
                Destroyed?.Invoke(this);
            }
        }
    }
}
