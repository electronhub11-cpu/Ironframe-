using System.Collections.Generic;
using UnityEngine;

namespace Ironframe
{
    /// <summary>Simple pooled kinetic projectile using Unity collision callbacks.</summary>
    public sealed class TankProjectile : MonoBehaviour
    {
        private static readonly Stack<TankProjectile> Pool = new Stack<TankProjectile>(16);
        private static Material _projectileMaterial;
        private Rigidbody _body;
        private SphereCollider _collider;
        private Transform _owner;
        private float _speed;
        private float _caliber;
        private float _damage;
        private float _life;
        private bool _mayReplicate;
        private bool _active;
        private readonly List<Collider> _ignoredColliders = new List<Collider>(8);

        public static TankProjectile Spawn(Transform owner, Vector3 origin, Vector3 direction, float speed, float caliberMm, float damage, bool authoritative)
        {
            TankProjectile projectile = null;
            while (Pool.Count > 0 && projectile == null) projectile = Pool.Pop();
            if (projectile == null)
            {
                var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                go.name = "IF_KineticProjectile";
                projectile = go.AddComponent<TankProjectile>();
                projectile.ConfigureVisuals();
            }
            projectile._owner = owner;
            projectile._speed = speed;
            projectile._caliber = caliberMm;
            projectile._damage = damage;
            projectile._life = 5f;
            projectile._mayReplicate = authoritative;
            projectile._active = true;
            projectile.transform.position = origin;
            projectile.transform.rotation = Quaternion.LookRotation(direction.normalized, Vector3.up);
            projectile.gameObject.SetActive(true);
            projectile._collider.enabled = true;
            projectile._body.isKinematic = false;
            projectile._body.velocity = direction.normalized * speed;
            projectile._body.angularVelocity = Vector3.zero;
            projectile._body.position = origin;
            projectile._body.rotation = projectile.transform.rotation;
            if (owner != null)
            {
                var ownerColliders = owner.GetComponentsInChildren<Collider>();
                foreach (var ownCollider in ownerColliders)
                {
                    if (ownCollider != null && ownCollider.enabled)
                    {
                        Physics.IgnoreCollision(projectile._collider, ownCollider, true);
                        projectile._ignoredColliders.Add(ownCollider);
                    }
                }
            }
            return projectile;
        }

        private void ConfigureVisuals()
        {
            _body = gameObject.AddComponent<Rigidbody>();
            _body.useGravity = true;
            _body.mass = 0.08f;
            _body.drag = 0f;
            _body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            _body.interpolation = RigidbodyInterpolation.Interpolate;
            _collider = GetComponent<SphereCollider>();
            _collider.radius = 0.09f;
            if (_projectileMaterial == null)
            {
                _projectileMaterial = Resources.Load<Material>("Ironframe/Materials/IF_Projectile");
                if (_projectileMaterial == null)
                {
                    var shader = Shader.Find("Universal Render Pipeline/Unlit");
                    if (shader == null) shader = Shader.Find("Unlit/Color");
                    _projectileMaterial = new Material(shader) { color = new Color(0.88f, 0.72f, 0.36f), enableInstancing = true };
                }
            }
            var renderer = GetComponent<Renderer>();
            renderer.sharedMaterial = _projectileMaterial;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        private void Update()
        {
            if (!_active) return;
            _life -= Time.deltaTime;
            if (_life <= 0f) ReturnToPool();
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (!_active) return;
            var other = collision.collider;
            if (_owner != null && (other.transform == _owner || other.transform.IsChildOf(_owner))) return;
            var target = other.GetComponentInParent<TankDamage>();
            if (target != null && _mayReplicate)
            {
                Vector3 point = collision.contactCount > 0 ? collision.GetContact(0).point : transform.position;
                target.ApplyProjectileHit(point, _body.velocity.normalized, _speed, _caliber, _damage, _owner != null ? _owner.gameObject : null);
            }
            ReturnToPool();
        }

        private void ReturnToPool()
        {
            if (!_active) return;
            _active = false;
            _body.velocity = Vector3.zero;
            _body.angularVelocity = Vector3.zero;
            _body.isKinematic = true;
            for (int i = 0; i < _ignoredColliders.Count; i++)
            {
                if (_ignoredColliders[i] != null) Physics.IgnoreCollision(_collider, _ignoredColliders[i], false);
            }
            _ignoredColliders.Clear();
            _collider.enabled = false;
            gameObject.SetActive(false);
            _owner = null;
            if (Pool.Count < 32) Pool.Push(this);
            else Destroy(gameObject);
        }
    }
}
