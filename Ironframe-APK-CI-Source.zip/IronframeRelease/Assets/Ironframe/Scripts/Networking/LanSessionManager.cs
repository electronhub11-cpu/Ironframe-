using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using System.Text;
using UnityEngine;

namespace Ironframe
{
    /// <summary>
    /// Small, manual-IP LAN transport for Wi-Fi/hotspot play. Host simulates remote player inputs;
    /// snapshots are intentionally compact. This is an initial prototype transport, not anti-cheat grade.
    /// </summary>
    public sealed class LanSessionManager : MonoBehaviour
    {
        public const int ProtocolVersion = 1;
        public const int Port = 27840;
        public const int MaximumPlayers = 4;
        public static LanSessionManager Instance { get; private set; }

        private UdpClient _socket;
        private IPEndPoint _hostEndpoint;
        private readonly Dictionary<int, TankController> _players = new Dictionary<int, TankController>();
        private readonly Dictionary<int, IPEndPoint> _endpoints = new Dictionary<int, IPEndPoint>();
        private readonly Dictionary<int, float> _lastHeard = new Dictionary<int, float>();
        private readonly Dictionary<int, uint> _lastInputSequence = new Dictionary<int, uint>();
        private TankController _localTank;
        private TankController _aiActor;
        private int _nextPlayerId = 2;
        private float _nextSnapshot;
        private float _nextInputSend;
        private float _nextJoinRetry;
        private uint _inputSequence;
        private bool _joinRejected;
        private float _lastHostPacketTime;
        private string _status = "Offline";
        private string _cachedLocalIPv4;

        public bool IsHost { get; private set; }
        public bool IsClient { get; private set; }
        public int LocalPlayerId { get; private set; }
        public TankController LocalTank => _localTank;
        public string Status => _status;
        public string AddressToJoin { get; set; } = "192.168.1.1";

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
        }

        public void Initialize(TankController localTank)
        {
            _localTank = localTank;
        }

        public void RegisterAIActor(TankController actor)
        {
            _aiActor = actor;
            if (actor != null) _players[-1] = actor;
        }

        public void ResetRemotePlayers()
        {
            if (!IsHost) return;
            foreach (var pair in _players)
            {
                int id = pair.Key;
                TankController tank = pair.Value;
                if (id <= 1 || tank == null) continue;
                if (tank.Damage != null) tank.Damage.ResetDamage();
                tank.transform.SetPositionAndRotation(new Vector3((id - 1) * 3.5f, 0.55f, -7f), Quaternion.identity);
                if (tank.Body != null)
                {
                    tank.Body.isKinematic = false;
                    tank.Body.velocity = Vector3.zero;
                    tank.Body.angularVelocity = Vector3.zero;
                }
                var collider = tank.GetComponent<Collider>();
                if (collider != null) collider.enabled = true;
                tank.SetRemoteInputs(0f, 0f, tank.TurretYaw, tank.GunPitch, false);
            }
            _status = "Hosting; remote players reset.";
        }

        public bool IsRegisteredPlayer(TankController tank)
        {
            foreach (var pair in _players)
                if (pair.Key > 0 && pair.Value == tank) return true;
            return false;
        }

        public string GetLocalIPv4Address()
        {
            if (!string.IsNullOrEmpty(_cachedLocalIPv4)) return _cachedLocalIPv4;
            // Cache this result: the UI may redraw many times each second, and interface enumeration
            // allocates on some Android runtimes. Refresh on StopSession/StartHost transitions.
            try
            {
                var interfaces = NetworkInterface.GetAllNetworkInterfaces();
                Array.Sort(interfaces, (a, b) => InterfacePriority(a).CompareTo(InterfacePriority(b)));
                foreach (var network in interfaces)
                {
                    if (network.OperationalStatus != OperationalStatus.Up ||
                        network.NetworkInterfaceType == NetworkInterfaceType.Loopback ||
                        network.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                    foreach (var entry in network.GetIPProperties().UnicastAddresses)
                    {
                        var address = entry.Address;
                        if (address.AddressFamily == AddressFamily.InterNetwork && IsPrivateIPv4(address))
                            return _cachedLocalIPv4 = address.ToString();
                    }
                }
            }
            catch (Exception ex) { Debug.LogWarning("Ironframe could not enumerate network interfaces: " + ex.Message); }

            try
            {
                var addresses = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                foreach (var address in addresses)
                    if (address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(address)) return _cachedLocalIPv4 = address.ToString();
            }
            catch (Exception ex) { Debug.LogWarning("Ironframe could not resolve local IPv4 address: " + ex.Message); }
            return _cachedLocalIPv4 = "Address unavailable";
        }

        private static int InterfacePriority(NetworkInterface network)
        {
            if (network == null) return 99;
            if (network.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) return 0;
            if (network.NetworkInterfaceType == NetworkInterfaceType.Ethernet) return 1;
            if (network.NetworkInterfaceType == NetworkInterfaceType.Tunnel || network.NetworkInterfaceType == NetworkInterfaceType.Loopback) return 99;
            return 5;
        }

        private static bool IsPrivateIPv4(IPAddress address)
        {
            byte[] b = address.GetAddressBytes();
            return b.Length == 4 && (b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168));
        }

        public void StartHost()
        {
            if (_localTank == null) { _status = "No local tank"; return; }
            StopSession();
            try
            {
                _socket = new UdpClient(Port);
                _socket.Client.Blocking = false;
                IsHost = true;
                LocalPlayerId = 1;
                _players[1] = _localTank;
                _endpoints.Clear();
                _lastHeard.Clear();
                _lastInputSequence.Clear();
                _nextPlayerId = 2;
                _localTank.IsLocalPlayer = true;
                _localTank.Fired += OnTankFired;
                if (_aiActor != null && _aiActor != _localTank) _aiActor.Fired += OnTankFired;
                _status = "Hosting on " + GetLocalIPv4Address() + ":" + Port;
            }
            catch (Exception ex)
            {
                StopSession();
                _status = "Host failed: " + ex.Message;
            }
        }

        public void StartClient(string hostAddress)
        {
            if (_localTank == null) { _status = "No local tank"; return; }
            if (!IPAddress.TryParse(hostAddress, out var ip) || ip.AddressFamily != AddressFamily.InterNetwork)
            {
                _status = "Enter a valid host IPv4 address";
                return;
            }
            StopSession();
            try
            {
                _socket = new UdpClient(0);
                _socket.Client.Blocking = false;
                _hostEndpoint = new IPEndPoint(ip, Port);
                IsClient = true;
                LocalPlayerId = 0;
                _joinRejected = false;
                _lastHostPacketTime = Time.unscaledTime;
                _players.Clear();
                _players[-1] = _aiActor;
                _localTank.IsLocalPlayer = true;
                if (_aiActor != null)
                {
                    var ai = _aiActor.GetComponent<TankAIController>();
                    if (ai != null) ai.enabled = false;
                    _aiActor.SetNetworkProxy(true);
                }
                _status = "Joining " + hostAddress + ":" + Port;
                SendJoin();
                _nextJoinRetry = Time.unscaledTime + 1f;
            }
            catch (Exception ex)
            {
                StopSession();
                _status = "Join failed: " + ex.Message;
            }
        }

        public void StopSession()
        {
            _cachedLocalIPv4 = null;
            if (_socket != null && IsHost)
            {
                foreach (var endpoint in _endpoints.Values) SendTo(endpoint, "HOSTCLOSE");
            }
            if (_localTank != null) _localTank.Fired -= OnTankFired;
            if (_aiActor != null) _aiActor.Fired -= OnTankFired;
            var handled = new HashSet<TankController>();
            foreach (var pair in _players)
            {
                var tank = pair.Value;
                if (tank == null || tank == _localTank || tank == _aiActor || !handled.Add(tank)) continue;
                Destroy(tank.gameObject);
            }
            _players.Clear();
            if (_localTank != null) _players[1] = _localTank;
            if (_aiActor != null) _players[-1] = _aiActor;
            _endpoints.Clear();
            _lastHeard.Clear();
            _lastInputSequence.Clear();
            if (_socket != null) { try { _socket.Close(); } catch { } _socket = null; }
            IsHost = false;
            IsClient = false;
            LocalPlayerId = 0;
            _hostEndpoint = null;
            _joinRejected = false;
            _lastHostPacketTime = 0f;
            _status = "Offline";
            if (_localTank != null) _localTank.SetNetworkProxy(false);
            if (_aiActor != null)
            {
                _aiActor.SetNetworkProxy(false);
                var ai = _aiActor.GetComponent<TankAIController>();
                if (ai != null) ai.enabled = true;
            }
        }

        private void OnDestroy()
        {
            StopSession();
            if (Instance == this) Instance = null;
        }

        private void Update()
        {
            if (_socket == null) return;
            ReceivePendingPackets();
            float now = Time.unscaledTime;
            if (IsHost)
            {
                if (now >= _nextSnapshot)
                {
                    _nextSnapshot = now + 0.10f;
                    BroadcastSnapshot();
                }
                PruneTimedOutPlayers(now);
            }
            else if (IsClient)
            {
                float hostTimeout = LocalPlayerId > 0 ? 6f : 8f;
                if (!_joinRejected && now - _lastHostPacketTime > hostTimeout)
                {
                    string reason = LocalPlayerId > 0 ? "Host connection lost." : "Host did not respond; check the IP and hotspot isolation.";
                    StopSession();
                    _status = reason;
                    return;
                }
                if (LocalPlayerId == 0 && !_joinRejected && now >= _nextJoinRetry)
                {
                    SendJoin();
                    _nextJoinRetry = now + 1.25f;
                }
                else if (LocalPlayerId > 0 && now >= _nextInputSend)
                {
                    _nextInputSend = now + 0.05f;
                    SendLocalInput();
                }
            }
        }

        private void ReceivePendingPackets()
        {
            int packets = 0;
            while (_socket != null && _socket.Available > 0 && packets < 32)
            {
                IPEndPoint remote = new IPEndPoint(IPAddress.Any, 0);
                byte[] data;
                try { data = _socket.Receive(ref remote); }
                catch (SocketException) { break; }
                catch (ObjectDisposedException) { break; }
                packets++;
                if (data == null || data.Length == 0 || data.Length > 1200) continue;
                string message = Encoding.UTF8.GetString(data);
                try
                {
                    if (IsHost) HandleHostMessage(message, remote);
                    else if (IsClient && _hostEndpoint != null && remote.Address.Equals(_hostEndpoint.Address))
                    {
                        _lastHostPacketTime = Time.unscaledTime;
                        HandleClientMessage(message);
                    }
                }
                catch (Exception ex) { Debug.LogWarning("Ironframe LAN packet ignored: " + ex.Message); }
            }
        }

        private void HandleHostMessage(string message, IPEndPoint remote)
        {
            string[] tokens = message.Split('|');
            if (tokens.Length == 0) return;
            if (tokens[0] == "JOIN" && tokens.Length >= 2)
            {
                if (!int.TryParse(tokens[1], out int version) || version != ProtocolVersion)
                {
                    SendTo(remote, "REJECT|Protocol mismatch");
                    return;
                }
                foreach (var pair in _endpoints)
                {
                    if (pair.Value.Equals(remote)) { SendTo(remote, "WELCOME|" + pair.Key); return; }
                }
                int activePlayers = 0;
                foreach (var id in _players.Keys) if (id > 0) activePlayers++;
                if (activePlayers >= MaximumPlayers)
                {
                    SendTo(remote, "REJECT|Session full");
                    return;
                }
                int idNew = _nextPlayerId++;
                Vector3 spawn = _localTank.transform.position + new Vector3((idNew - 1) * 3.5f, 0f, -7f);
                var remoteTank = TankFactory.CreateTank("IF_NetworkPlayer_" + idNew, spawn, Quaternion.identity, false, false);
                remoteTank.IsNetworkControlled = true;
                remoteTank.Fired += OnTankFired;
                _players[idNew] = remoteTank;
                _endpoints[idNew] = remote;
                _lastHeard[idNew] = Time.unscaledTime;
                _lastInputSequence[idNew] = 0u;
                SendTo(remote, "WELCOME|" + idNew);
                _status = "Hosting; " + (activePlayers + 1) + "/" + MaximumPlayers + " players";
                return;
            }
            if (tokens[0] != "INPUT" || tokens.Length < 8) return;
            if (!int.TryParse(tokens[1], out int id) || !_players.TryGetValue(id, out var tank)) return;
            if (!_endpoints.TryGetValue(id, out var expected) || !expected.Equals(remote)) return;
            if (tokens.Length < 8 || !uint.TryParse(tokens[7], NumberStyles.Integer, CultureInfo.InvariantCulture, out uint sequence)) return;
            if (_lastInputSequence.TryGetValue(id, out uint lastSequence) && unchecked((int)(sequence - lastSequence)) <= 0) return;
            _lastInputSequence[id] = sequence;
            float throttle = ParseFloat(tokens[2]);
            float steer = ParseFloat(tokens[3]);
            float yaw = ParseFloat(tokens[4]);
            float pitch = ParseFloat(tokens[5]);
            bool fire = tokens[6] == "1";
            tank.SetRemoteInputs(Mathf.Clamp(throttle, -1f, 1f), Mathf.Clamp(steer, -1f, 1f), Mathf.Clamp(yaw, -180f, 180f), Mathf.Clamp(pitch, -8f, 25f), fire);
            _lastHeard[id] = Time.unscaledTime;
        }

        private void HandleClientMessage(string message)
        {
            string[] tokens = message.Split('|');
            if (tokens.Length == 0) return;
            if (tokens[0] == "WELCOME" && tokens.Length >= 2 && int.TryParse(tokens[1], out int id))
            {
                LocalPlayerId = id;
                _players[id] = _localTank;
                _localTank.Fired -= OnTankFired;
                _status = "Connected to " + _hostEndpoint.Address + " as player " + id;
            }
            else if (tokens[0] == "REJECT")
            {
                _joinRejected = true;
                _status = tokens.Length > 1 ? "Rejected: " + tokens[1] : "Rejected by host";
            }
            else if (tokens[0] == "HOSTCLOSE")
            {
                StopSession();
                _status = "Host ended the session.";
            }
            else if (tokens[0] == "LEAVE" && tokens.Length >= 2 && int.TryParse(tokens[1], out int leavingId))
            {
                if (_players.TryGetValue(leavingId, out var leavingTank) && leavingTank != null && leavingTank != _localTank && leavingTank != _aiActor)
                    Destroy(leavingTank.gameObject);
                _players.Remove(leavingId);
            }
            else if (tokens[0] == "STATE" && tokens.Length >= 2) ApplySnapshot(message.Substring(6));
            else if (tokens[0] == "FIRE" && tokens.Length >= 11) ApplyFirePacket(tokens);
        }

        private void ApplySnapshot(string payload)
        {
            string[] entities = payload.Split(';');
            foreach (string entity in entities)
            {
                if (string.IsNullOrEmpty(entity)) continue;
                string[] v = entity.Split(',');
                if (v.Length < 12 || !int.TryParse(v[0], out int id)) continue;
                float x = ParseFloat(v[1]), y = ParseFloat(v[2]), z = ParseFloat(v[3]);
                Quaternion rot = new Quaternion(ParseFloat(v[4]), ParseFloat(v[5]), ParseFloat(v[6]), ParseFloat(v[7]));
                float yaw = ParseFloat(v[8]), pitch = ParseFloat(v[9]), health = ParseFloat(v[10]);
                bool destroyed = v[11] == "1";
                if (!_players.TryGetValue(id, out var tank) || tank == null)
                {
                    if (id == LocalPlayerId || id == 1 && _localTank == null) continue;
                    tank = TankFactory.CreateTank("IF_Remote_" + id, new Vector3(x, y, z), rot, false, false);
                    tank.SetNetworkProxy(true);
                    _players[id] = tank;
                }
                tank.ApplyNetworkPose(new Vector3(x, y, z), rot, yaw, pitch, health, destroyed, id == LocalPlayerId);
            }
        }

        private void ApplyFirePacket(string[] tokens)
        {
            int id = int.Parse(tokens[1], CultureInfo.InvariantCulture);
            Vector3 origin = new Vector3(ParseFloat(tokens[2]), ParseFloat(tokens[3]), ParseFloat(tokens[4]));
            Vector3 direction = new Vector3(ParseFloat(tokens[5]), ParseFloat(tokens[6]), ParseFloat(tokens[7])).normalized;
            float speed = ParseFloat(tokens[8]);
            float caliber = tokens.Length > 9 ? ParseFloat(tokens[9]) : 75f;
            float damage = tokens.Length > 10 ? ParseFloat(tokens[10]) : 36f;
            Transform owner = _players.TryGetValue(id, out var tank) && tank != null ? tank.transform : null;
            if (tank != null)
            {
                var audio = tank.GetComponent<TankAudio>();
                if (audio != null) audio.PlayReplicatedShot();
            }
            TankController.SpawnReplicaProjectile(owner, origin, direction, speed, caliber, damage);
        }

        private void SendJoin() { SendTo(_hostEndpoint, "JOIN|" + ProtocolVersion + "|Ironframe"); }

        private void SendLocalInput()
        {
            if (_localTank == null || LocalPlayerId <= 0) return;
            _inputSequence++;
            string message = "INPUT|" + LocalPlayerId + "|" + F(_localTank.ThrottleInput) + "|" + F(_localTank.SteerInput) + "|" + F(_localTank.TurretYaw) + "|" + F(_localTank.GunPitch) + "|" + (_localTank.FireHeld ? "1" : "0") + "|" + _inputSequence;
            SendTo(_hostEndpoint, message);
        }

        private void BroadcastSnapshot()
        {
            if (_endpoints.Count == 0) return;
            var sb = new StringBuilder(768);
            sb.Append("STATE|");
            bool first = true;
            foreach (var pair in _players)
            {
                var tank = pair.Value;
                if (tank == null) continue;
                if (!first) sb.Append(';');
                first = false;
                Vector3 p = tank.transform.position;
                Quaternion q = tank.transform.rotation;
                float health = tank.Damage != null ? tank.Damage.Health : 0f;
                bool dead = tank.Damage != null && tank.Damage.IsDestroyed;
                sb.Append(pair.Key).Append(',').Append(F(p.x)).Append(',').Append(F(p.y)).Append(',').Append(F(p.z)).Append(',')
                    .Append(F(q.x)).Append(',').Append(F(q.y)).Append(',').Append(F(q.z)).Append(',').Append(F(q.w)).Append(',')
                    .Append(F(tank.TurretYaw)).Append(',').Append(F(tank.GunPitch)).Append(',').Append(F(health)).Append(',').Append(dead ? '1' : '0');
            }
            byte[] data = Encoding.UTF8.GetBytes(sb.ToString());
            foreach (var endpoint in _endpoints.Values)
            {
                try { _socket.Send(data, data.Length, endpoint); }
                catch (Exception ex) { Debug.LogWarning("Snapshot send failed: " + ex.Message); }
            }
        }

        private void OnTankFired(TankController owner, Vector3 origin, Vector3 direction, float speed, float caliber, float damage)
        {
            if (!IsHost || _socket == null) return;
            int id = 0;
            foreach (var pair in _players) if (pair.Value == owner) { id = pair.Key; break; }
            string message = "FIRE|" + id + "|" + F(origin.x) + "|" + F(origin.y) + "|" + F(origin.z) + "|" + F(direction.x) + "|" + F(direction.y) + "|" + F(direction.z) + "|" + F(speed) + "|" + F(caliber) + "|" + F(damage);
            foreach (var endpoint in _endpoints.Values) SendTo(endpoint, message);
        }

        private void PruneTimedOutPlayers(float now)
        {
            var expired = new List<int>();
            foreach (var pair in _lastHeard) if (now - pair.Value > 10f) expired.Add(pair.Key);
            foreach (int id in expired)
            {
                foreach (var endpoint in _endpoints)
                    if (endpoint.Key != id) SendTo(endpoint.Value, "LEAVE|" + id);
                if (_players.TryGetValue(id, out var tank) && tank != null) { tank.Fired -= OnTankFired; Destroy(tank.gameObject); }
                _players.Remove(id); _endpoints.Remove(id); _lastHeard.Remove(id); _lastInputSequence.Remove(id);
            }
        }

        private void SendTo(IPEndPoint endpoint, string message)
        {
            if (_socket == null || endpoint == null) return;
            try { byte[] bytes = Encoding.UTF8.GetBytes(message); if (bytes.Length <= 1200) _socket.Send(bytes, bytes.Length, endpoint); }
            catch (Exception ex) { Debug.LogWarning("LAN send failed: " + ex.Message); }
        }

        private static float ParseFloat(string s)
        {
            if (!float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out float value)) return 0f;
            return float.IsNaN(value) || float.IsInfinity(value) ? 0f : value;
        }

        private static string F(float value) { return value.ToString("F3", CultureInfo.InvariantCulture); }
    }
}
