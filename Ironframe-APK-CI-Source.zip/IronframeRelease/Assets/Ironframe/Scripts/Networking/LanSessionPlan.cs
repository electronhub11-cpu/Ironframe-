using System.Net;

namespace Ironframe.Networking
{
    /// <summary>Shared LAN settings for the direct-IPv4 UDP prototype transport.</summary>
    public static class LanSessionPlan
    {
        public const ushort DefaultPort = 27840;
        public const int ProtocolVersion = 1;
        public const int MaxPlayers = 4;

        public static bool IsSupportedLocalAddress(string address)
        {
            if (!IPAddress.TryParse(address, out var ip) || ip.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork) return false;
            byte[] b = ip.GetAddressBytes();
            return b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168);
        }
    }
}
