using UnityEngine;

namespace Ironframe
{
    public sealed class TankCameraFollow : MonoBehaviour
    {
        public Transform target;
        [SerializeField] private Vector3 offset = new Vector3(0f, 5.5f, -9.5f);
        [SerializeField] private float smooth = 7f;
        private void LateUpdate()
        {
            if (target == null) return;
            Vector3 desired = target.TransformPoint(offset);
            transform.position = Vector3.Lerp(transform.position, desired, 1f - Mathf.Exp(-smooth * Time.deltaTime));
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(target.position + target.forward * 4f + Vector3.up * 0.8f - transform.position), 1f - Mathf.Exp(-smooth * Time.deltaTime));
        }
    }
}
