using System;
using UnityEngine;

namespace Ironframe
{
    [RequireComponent(typeof(Rigidbody), typeof(TankBuildController), typeof(TankDamage))]
    public sealed class TankController : MonoBehaviour
    {
        public const float ProjectileSpeed = 600f;
        public const float ProjectileCaliberMm = 75f;
        public const float ProjectileDamage = 36f;

        [SerializeField] private float engineForceNewtons = 132000f;
        [SerializeField] private float yawTorque = 150000f;
        [SerializeField] private float maximumSpeed = 9.0f;
        [SerializeField] private float fireInterval = 1.6f;

        private Rigidbody _body;
        private TankBuildController _build;
        private TankDamage _damage;
        private float _throttle;
        private float _steer;
        private float _aimX;
        private float _aimY;
        private float _cooldown;
        private bool _fireHeld;
        private bool _isNetworkProxy;

        public bool IsLocalPlayer { get; set; }
        public bool IsNetworkControlled { get; set; }
        public bool IsNetworkProxy => _isNetworkProxy;
        public TankBuildController Build => _build;
        public TankDamage Damage => _damage;
        public Rigidbody Body => _body;
        public float CurrentSpeedMps => _body != null ? _body.velocity.magnitude : 0f;
        public float TurretYaw => _build != null ? _build.AimYaw : 0f;
        public float GunPitch => _build != null ? _build.AimPitch : 0f;
        public float ThrottleInput => _throttle;
        public float SteerInput => _steer;
        public bool FireHeld => _fireHeld;
        public event Action<TankController, Vector3, Vector3, float, float, float> Fired;

        private void Awake()
        {
            _body = GetComponent<Rigidbody>();
            _build = GetComponent<TankBuildController>();
            _damage = GetComponent<TankDamage>();
        }

        public void SetDriveInput(float throttle, float steer)
        {
            _throttle = Mathf.Clamp(throttle, -1f, 1f);
            _steer = Mathf.Clamp(steer, -1f, 1f);
        }

        public void SetAimInput(float yawAxis, float pitchAxis)
        {
            _aimX = Mathf.Clamp(yawAxis, -1f, 1f);
            _aimY = Mathf.Clamp(pitchAxis, -1f, 1f);
        }

        public void SetFireHeld(bool held) { _fireHeld = held; }

        public void SetRemoteInputs(float throttle, float steer, float yaw, float pitch, bool fire)
        {
            SetDriveInput(throttle, steer);
            _build.SetAimAngles(yaw, pitch);
            _fireHeld = fire;
        }

        public void AimAtWorldPoint(Vector3 target)
        {
            if (_build == null || _build.TurretPivot == null) return;
            Vector3 direction = transform.InverseTransformDirection(target - _build.TurretPivot.position);
            float distance = new Vector2(direction.x, direction.z).magnitude;
            float yaw = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg - _build.Blueprint.turretYawOffset;
            float pitch = Mathf.Atan2(direction.y, Mathf.Max(0.1f, distance)) * Mathf.Rad2Deg;
            _build.SetAimAngles(yaw, pitch);
        }

        private void Update()
        {
            _cooldown -= Time.deltaTime;
            if (_damage != null && _damage.IsDestroyed) { _fireHeld = false; return; }

            // Client shots are requested through INPUT; only the host creates authoritative projectiles.
            var net = LanSessionManager.Instance;
            bool isClientLocal = net != null && net.IsClient && net.LocalTank == this;
            if (_fireHeld && _cooldown <= 0f && !isClientLocal) FireAuthoritative();

            if (_aimX != 0f || _aimY != 0f)
            {
                float turretCondition = _damage != null ? Mathf.Lerp(0.25f, 1f, _damage.TurretCondition) : 1f;
                _build.SetAimAngles(_build.AimYaw + _aimX * 95f * turretCondition * Time.deltaTime, _build.AimPitch + _aimY * 55f * turretCondition * Time.deltaTime);
            }
        }

        private void FixedUpdate()
        {
            if (_isNetworkProxy || _body == null || (_damage != null && _damage.IsDestroyed)) return;
            float speed = Vector3.Dot(_body.velocity, transform.forward);
            float engineScale = _damage != null ? _damage.EngineCondition : 1f;
            float massScale = Mathf.Clamp(18000f / Mathf.Max(6000f, _body.mass), 0.55f, 1.4f);
            if (Mathf.Abs(speed) < maximumSpeed || Mathf.Sign(_throttle) != Mathf.Sign(speed))
                _body.AddForce(transform.forward * (_throttle * engineForceNewtons / Mathf.Max(6000f, _body.mass)) * engineScale * massScale, ForceMode.Acceleration);

            float steerAuthority = Mathf.Lerp(1f, 0.38f, Mathf.Clamp01(Mathf.Abs(speed) / maximumSpeed));
            _body.AddTorque(Vector3.up * (_steer * yawTorque / Mathf.Max(1f, _body.mass / 5000f)) * steerAuthority, ForceMode.Force);

            Vector3 horizontalVelocity = new Vector3(_body.velocity.x, 0f, _body.velocity.z);
            if (horizontalVelocity.magnitude > maximumSpeed)
            {
                horizontalVelocity = horizontalVelocity.normalized * maximumSpeed;
                _body.velocity = new Vector3(horizontalVelocity.x, _body.velocity.y, horizontalVelocity.z);
            }
        }

        private void FireAuthoritative()
        {
            _cooldown = fireInterval;
            if (_build == null || _build.Muzzle == null) return;
            Vector3 origin = _build.Muzzle.position;
            Vector3 direction = _build.Muzzle.forward;
            TankProjectile.Spawn(transform, origin, direction, ProjectileSpeed, ProjectileCaliberMm, ProjectileDamage, true);
            _build.TriggerRecoil();
            // Shell momentum is physically small relative to a heavy tank; visible recoil is animated
            // at the gun pivot, while this impulse preserves a small physical response.
            if (_body != null) _body.AddForceAtPosition(-direction.normalized * (ProjectileSpeed * 0.08f), origin, ForceMode.Impulse);
            Fired?.Invoke(this, origin, direction, ProjectileSpeed, ProjectileCaliberMm, ProjectileDamage);
        }

        public void SetNetworkProxy(bool proxy)
        {
            _isNetworkProxy = proxy;
            if (_body != null)
            {
                _body.isKinematic = proxy;
                if (proxy) _body.velocity = Vector3.zero;
            }
            var rootCollider = GetComponent<Collider>();
            if (rootCollider != null && (_damage == null || !_damage.IsDestroyed)) rootCollider.enabled = !proxy;
        }

        public void ApplyNetworkPose(Vector3 position, Quaternion rotation, float turretYaw, float gunPitch, float health, bool destroyed, bool ownTank)
        {
            if (_build != null) _build.SetAimAngles(turretYaw, gunPitch);
            if (ownTank)
            {
                if (_body != null && !_damage.IsDestroyed)
                {
                    _body.MovePosition(Vector3.Lerp(_body.position, position, 0.35f));
                    _body.MoveRotation(Quaternion.Slerp(_body.rotation, rotation, 0.35f));
                }
            }
            else
            {
                _isNetworkProxy = true;
                if (_body != null) { _body.isKinematic = true; _body.velocity = Vector3.zero; }
                transform.position = Vector3.Lerp(transform.position, position, 0.45f);
                transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 0.45f);
            }
            if (_damage != null) _damage.ApplyNetworkHealth(health, destroyed);
        }

        public static void SpawnReplicaProjectile(Transform owner, Vector3 origin, Vector3 direction, float speed, float caliber, float damage)
        {
            TankProjectile.Spawn(owner, origin, direction, speed, caliber, damage, false);
        }
    }
}
