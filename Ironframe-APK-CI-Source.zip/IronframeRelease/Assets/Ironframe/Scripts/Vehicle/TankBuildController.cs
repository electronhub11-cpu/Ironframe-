using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Ironframe
{
    [Serializable]
    public sealed class TankModuleRecord
    {
        public string type;
        public Vector3 position;
        public Vector3 scale = Vector3.one;
        public float armorMm;
        public float massKg;
        public bool visible = true;
    }

    [Serializable]
    public sealed class TankBlueprint
    {
        public int schemaVersion = 1;
        public string tankName = "IF-01";
        public float frontArmorMm = 80f;
        public float sideArmorMm = 45f;
        public float rearArmorMm = 30f;
        public float turretArmorMm = 65f;
        public float turretYawOffset;
        public float gunPitchOffset;
        public List<TankModuleRecord> modules = new List<TankModuleRecord>();
    }

    /// <summary>Runtime low-poly model generator and serializable construction data.</summary>
    public sealed class TankBuildController : MonoBehaviour
    {
        private const string BlueprintFileName = "ironframe_blueprint.json";
        private static readonly Dictionary<int, Material> MaterialCache = new Dictionary<int, Material>();

        [SerializeField] private TankBlueprint blueprint = new TankBlueprint();
        private Transform _visualRoot;
        private Vector3 _gunPivotRestPosition = new Vector3(0f, 0.05f, 0.55f);
        private float _recoilOffset;
        private float _aimYaw;
        private float _aimPitch;

        public TankBlueprint Blueprint => blueprint;
        public Transform TurretPivot { get; private set; }
        public Transform GunPivot { get; private set; }
        public Transform Muzzle { get; private set; }
        public float TotalMassKg { get; private set; }
        public Vector3 LocalCenterOfMass { get; private set; }
        public float AimYaw => _aimYaw;
        public float AimPitch => _aimPitch;

        private void Start()
        {
            if (blueprint == null || blueprint.modules == null || blueprint.modules.Count == 0) InitializeDefault();
            else if (_visualRoot == null) RebuildModel();
        }

        public void InitializeDefault()
        {
            blueprint = CreateDefaultBlueprint();
            RebuildModel();
        }

        public static TankBlueprint CreateDefaultBlueprint()
        {
            var b = new TankBlueprint();
            b.modules = new List<TankModuleRecord>
            {
                Part("Hull", new Vector3(0f, 0.15f, 0f), new Vector3(2.8f, 0.72f, 4.0f), 80f, 8800f, true),
                Part("Turret", new Vector3(0f, 0.65f, -0.15f), new Vector3(1.65f, 0.62f, 1.65f), 65f, 3800f, true),
                Part("Gun", Vector3.zero, new Vector3(0.23f, 0.23f, 2.15f), 25f, 850f, true),
                Part("Mantlet", new Vector3(0f, 0f, 0.6f), new Vector3(0.58f, 0.48f, 0.55f), 90f, 550f, true),
                Part("TrackLeft", new Vector3(-1.52f, -0.07f, 0f), new Vector3(0.38f, 0.72f, 4.25f), 25f, 1250f, true),
                Part("TrackRight", new Vector3(1.52f, -0.07f, 0f), new Vector3(0.38f, 0.72f, 4.25f), 25f, 1250f, true),
                Part("Engine", new Vector3(0f, 0f, -1.15f), Vector3.one, 0f, 1250f, false),
                Part("Transmission", new Vector3(0f, 0f, -0.45f), Vector3.one, 0f, 450f, false),
                Part("Fuel", new Vector3(-0.55f, 0f, -0.35f), Vector3.one, 0f, 420f, false),
                Part("Ammo", new Vector3(0.45f, 0.05f, 0.1f), Vector3.one, 0f, 520f, false),
                Part("WheelSet", new Vector3(0f, 0f, 0f), Vector3.one, 20f, 720f, true)
            };
            return b;
        }

        private static TankModuleRecord Part(string type, Vector3 position, Vector3 scale, float armor, float mass, bool visible)
        {
            return new TankModuleRecord { type = type, position = position, scale = scale, armorMm = armor, massKg = mass, visible = visible };
        }

        public void RebuildModel()
        {
            if (blueprint == null) blueprint = CreateDefaultBlueprint();
            if (blueprint.modules == null) blueprint.modules = new List<TankModuleRecord>();

            if (_visualRoot != null) Destroy(_visualRoot.gameObject);
            var root = new GameObject("Visuals");
            root.transform.SetParent(transform, false);
            _visualRoot = root.transform;

            TurretPivot = new GameObject("TurretPivot").transform;
            TurretPivot.SetParent(_visualRoot, false);
            TurretPivot.localPosition = new Vector3(0f, 0.65f, -0.15f);

            GunPivot = new GameObject("GunPivot").transform;
            GunPivot.SetParent(TurretPivot, false);
            GunPivot.localPosition = new Vector3(0f, 0.05f, 0.55f);
            _gunPivotRestPosition = GunPivot.localPosition;

            Muzzle = new GameObject("Muzzle").transform;
            Muzzle.SetParent(GunPivot, false);
            Muzzle.localPosition = new Vector3(0f, 0f, 2.08f);

            bool hasHull = false, hasTurret = false, hasGun = false, hasLeftTrack = false, hasRightTrack = false;
            bool hasWheels = false;
            foreach (var module in blueprint.modules)
            {
                if (module == null || !module.visible || string.IsNullOrEmpty(module.type)) continue;
                switch (module.type)
                {
                    case "Hull":
                        MakeBlock(_visualRoot, "Hull", module.position, module.scale, new Color(0.25f, 0.32f, 0.27f)); hasHull = true; break;
                    case "Turret":
                        TurretPivot.localPosition = module.position;
                        MakeBlock(TurretPivot, "Turret", Vector3.zero, module.scale, new Color(0.31f, 0.38f, 0.31f)); hasTurret = true; break;
                    case "Gun":
                        MakeBlock(GunPivot, "GunBarrel", new Vector3(0f, 0f, module.scale.z * 0.49f), module.scale, new Color(0.15f, 0.18f, 0.16f));
                        Muzzle.localPosition = new Vector3(0f, 0f, module.scale.z * 0.98f); hasGun = true; break;
                    case "Mantlet":
                        MakeBlock(GunPivot, "Mantlet", module.position, module.scale, new Color(0.27f, 0.33f, 0.28f)); break;
                    case "TrackLeft":
                        MakeBlock(_visualRoot, "Track_Left", module.position, module.scale, new Color(0.105f, 0.12f, 0.11f)); hasLeftTrack = true; break;
                    case "TrackRight":
                        MakeBlock(_visualRoot, "Track_Right", module.position, module.scale, new Color(0.105f, 0.12f, 0.11f)); hasRightTrack = true; break;
                    case "WheelSet":
                    {
                        int wheelCount = Mathf.Clamp(5 + Mathf.RoundToInt((module.massKg - 720f) / 180f), 5, 10);
                        MakeWheels(_visualRoot, wheelCount); hasWheels = true; break;
                    }
                    case "ArmorPlate":
                        MakeBlock(_visualRoot, "Addon_Armor", module.position, module.scale, new Color(0.40f, 0.43f, 0.36f)); break;
                    case "SmokeLauncher":
                        MakeBlock(_visualRoot, "Smoke_Launcher_L", new Vector3(-0.58f, 0.55f, -0.55f), new Vector3(0.25f, 0.22f, 0.55f), new Color(0.12f, 0.14f, 0.13f));
                        MakeBlock(_visualRoot, "Smoke_Launcher_R", new Vector3(0.58f, 0.55f, -0.55f), new Vector3(0.25f, 0.22f, 0.55f), new Color(0.12f, 0.14f, 0.13f)); break;
                    case "ExtraFuel":
                        MakeBlock(_visualRoot, "External_Fuel", module.position, module.scale, new Color(0.19f, 0.23f, 0.20f)); break;
                }
            }

            if (!hasHull) MakeBlock(_visualRoot, "Hull_Fallback", new Vector3(0f, 0.15f, 0f), new Vector3(2.8f, 0.72f, 4f), new Color(0.25f, 0.32f, 0.27f));
            if (!hasTurret) MakeBlock(TurretPivot, "Turret_Fallback", Vector3.zero, new Vector3(1.65f, 0.62f, 1.65f), new Color(0.31f, 0.38f, 0.31f));
            if (!hasGun) MakeBlock(GunPivot, "Gun_Fallback", new Vector3(0f, 0f, 1.0f), new Vector3(0.23f, 0.23f, 2.15f), new Color(0.15f, 0.18f, 0.16f));
            if (!hasLeftTrack) MakeBlock(_visualRoot, "Track_Left_Fallback", new Vector3(-1.52f, -0.07f, 0f), new Vector3(0.38f, 0.72f, 4.25f), new Color(0.105f, 0.12f, 0.11f));
            if (!hasRightTrack) MakeBlock(_visualRoot, "Track_Right_Fallback", new Vector3(1.52f, -0.07f, 0f), new Vector3(0.38f, 0.72f, 4.25f), new Color(0.105f, 0.12f, 0.11f));
            if (!hasWheels) MakeWheels(_visualRoot, 5);

            RecalculateMassProperties();
            ApplyAim(_aimYaw, _aimPitch);
        }

        private static void MakeWheels(Transform parent, int countPerSide)
        {
            countPerSide = Mathf.Clamp(countPerSide, 5, 10);
            for (int side = -1; side <= 1; side += 2)
            {
                for (int i = 0; i < countPerSide; i++)
                {
                    var wheel = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    wheel.name = "RoadWheel";
                    wheel.transform.SetParent(parent, false);
                    float z = countPerSide <= 1 ? 0f : Mathf.Lerp(-1.72f, 1.72f, i / (float)(countPerSide - 1));
                    wheel.transform.localPosition = new Vector3(side * 1.36f, -0.18f, z);
                    wheel.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                    wheel.transform.localScale = new Vector3(0.24f, 0.18f, 0.24f);
                    var col = wheel.GetComponent<Collider>(); if (col != null) col.enabled = false;
                    var renderer = wheel.GetComponent<Renderer>();
                    renderer.sharedMaterial = GetMaterial(new Color(0.16f, 0.18f, 0.16f));
                    renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                    renderer.receiveShadows = false;
                }
            }
        }

        private static void MakeBlock(Transform parent, string name, Vector3 position, Vector3 scale, Color color)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            var collider = go.GetComponent<Collider>(); if (collider != null) collider.enabled = false;
            var renderer = go.GetComponent<Renderer>();
            renderer.sharedMaterial = GetMaterial(color);
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        private static Material GetMaterial(Color color)
        {
            int key = color.GetHashCode();
            if (MaterialCache.TryGetValue(key, out var cached) && cached != null) return cached;
            string resourceName = MaterialResourceName(color);
            Material material = string.IsNullOrEmpty(resourceName) ? null : Resources.Load<Material>("Ironframe/Materials/" + resourceName);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
                if (shader == null) shader = Shader.Find("Unlit/Color");
                material = new Material(shader) { color = color, enableInstancing = true };
            }
            MaterialCache[key] = material;
            return material;
        }

        private static string MaterialResourceName(Color c)
        {
            if (Near(c, new Color(0.25f, 0.32f, 0.27f))) return "IF_Hull";
            if (Near(c, new Color(0.31f, 0.38f, 0.31f)) || Near(c, new Color(0.27f, 0.33f, 0.28f))) return "IF_Turret";
            if (Near(c, new Color(0.15f, 0.18f, 0.16f))) return "IF_Gun";
            if (Near(c, new Color(0.105f, 0.12f, 0.11f)) || Near(c, new Color(0.12f, 0.14f, 0.13f))) return "IF_Track";
            if (Near(c, new Color(0.16f, 0.18f, 0.16f))) return "IF_Wheel";
            if (Near(c, new Color(0.40f, 0.43f, 0.36f))) return "IF_Armor";
            if (Near(c, new Color(0.19f, 0.23f, 0.20f))) return "IF_Fuel";
            return null;
        }

        private static bool Near(Color a, Color b)
        {
            return Mathf.Abs(a.r - b.r) < 0.002f && Mathf.Abs(a.g - b.g) < 0.002f && Mathf.Abs(a.b - b.b) < 0.002f;
        }

        private void Update()
        {
            if (GunPivot == null) return;
            _recoilOffset = Mathf.MoveTowards(_recoilOffset, 0f, Time.deltaTime * 0.85f);
            GunPivot.localPosition = _gunPivotRestPosition + Vector3.back * _recoilOffset;
        }

        public void TriggerRecoil()
        {
            _recoilOffset = Mathf.Min(0.20f, _recoilOffset + 0.14f);
        }

        public void RecalculateMassProperties()
        {
            float mass = 0f;
            Vector3 weighted = Vector3.zero;
            foreach (var module in blueprint.modules)
            {
                if (module == null) continue;
                float m = Mathf.Max(0f, module.massKg);
                mass += m;
                weighted += module.position * m;
            }
            TotalMassKg = Mathf.Max(1000f, mass);
            LocalCenterOfMass = mass > 0f ? weighted / mass : Vector3.zero;
            var body = GetComponent<Rigidbody>();
            if (body != null)
            {
                body.mass = TotalMassKg;
                body.centerOfMass = LocalCenterOfMass;
            }
        }

        public void SetAimAngles(float yaw, float pitch)
        {
            _aimYaw = Mathf.Clamp(yaw, -180f, 180f);
            _aimPitch = Mathf.Clamp(pitch, -8f, 25f);
            ApplyAim(_aimYaw, _aimPitch);
        }

        private void ApplyAim(float yaw, float pitch)
        {
            if (TurretPivot != null) TurretPivot.localRotation = Quaternion.Euler(0f, yaw + (blueprint != null ? blueprint.turretYawOffset : 0f), 0f);
            if (GunPivot != null) GunPivot.localRotation = Quaternion.Euler(-(pitch + (blueprint != null ? blueprint.gunPitchOffset : 0f)), 0f, 0f);
        }

        public void RotateTurretOffset(float degrees)
        {
            blueprint.turretYawOffset = Mathf.Repeat(blueprint.turretYawOffset + degrees + 180f, 360f) - 180f;
            ApplyAim(_aimYaw, _aimPitch);
        }

        public void MoveTurretSnap(Vector3 localDelta)
        {
            var turret = blueprint.modules.Find(m => m != null && m.type == "Turret");
            if (turret == null) return;
            Vector3 p = turret.position + localDelta;
            p.x = Mathf.Clamp(Mathf.Round(p.x / 0.25f) * 0.25f, -0.65f, 0.65f);
            p.z = Mathf.Clamp(Mathf.Round(p.z / 0.25f) * 0.25f, -0.75f, 0.75f);
            p.y = Mathf.Clamp(Mathf.Round(p.y / 0.25f) * 0.25f, 0.5f, 1.0f);
            turret.position = p;
            RebuildModel();
        }

        public void RemoveLastAddon()
        {
            for (int i = blueprint.modules.Count - 1; i >= 0; i--)
            {
                var module = blueprint.modules[i];
                if (module == null) continue;
                if (module.type == "ArmorPlate")
                {
                    blueprint.modules.RemoveAt(i);
                    blueprint.frontArmorMm = Mathf.Max(20f, blueprint.frontArmorMm - 10f);
                    RebuildModel();
                    return;
                }
                if (module.type == "SmokeLauncher" || module.type == "ExtraFuel")
                {
                    blueprint.modules.RemoveAt(i);
                    RebuildModel();
                    return;
                }
            }
        }

        public void AdjustArmor(float deltaMm)
        {
            blueprint.frontArmorMm = Mathf.Clamp(blueprint.frontArmorMm + deltaMm, 20f, 220f);
            blueprint.sideArmorMm = Mathf.Clamp(blueprint.sideArmorMm + deltaMm * 0.35f, 15f, 120f);
            var hull = blueprint.modules.Find(m => m != null && m.type == "Hull");
            if (hull != null)
            {
                hull.armorMm = blueprint.frontArmorMm;
                // Approximate mass scaling for the armor settings; this is a gameplay estimate,
                // not a detailed plate-by-plate engineering calculation.
                float baselineWeightedThickness = 80f * 0.4f + 45f * 0.4f + 30f * 0.2f;
                float currentWeightedThickness = blueprint.frontArmorMm * 0.4f + blueprint.sideArmorMm * 0.4f + blueprint.rearArmorMm * 0.2f;
                hull.massKg = 8800f * currentWeightedThickness / baselineWeightedThickness;
            }
            RecalculateMassProperties();
        }

        public void AddArmorPlate()
        {
            int count = blueprint.modules.FindAll(m => m != null && m.type == "ArmorPlate").Count;
            if (count >= 8) return;
            float x = count % 2 == 0 ? -0.72f : 0.72f;
            float z = 1.92f + (count / 2) * 0.025f;
            blueprint.modules.Add(Part("ArmorPlate", new Vector3(x, 0.2f, z), new Vector3(0.8f, 0.48f, 0.16f), 20f, 125f, true));
            blueprint.frontArmorMm = Mathf.Min(220f, blueprint.frontArmorMm + 10f);
            RebuildModel();
        }

        public void AddSmokeLaunchers()
        {
            if (blueprint.modules.Exists(m => m != null && m.type == "SmokeLauncher")) return;
            blueprint.modules.Add(Part("SmokeLauncher", Vector3.zero, Vector3.one, 0f, 90f, true));
            RebuildModel();
        }

        public void AddExternalFuel()
        {
            if (blueprint.modules.Exists(m => m != null && m.type == "ExtraFuel")) return;
            blueprint.modules.Add(Part("ExtraFuel", new Vector3(1.05f, 0.2f, -1.2f), new Vector3(0.38f, 0.62f, 1.05f), 10f, 260f, true));
            RebuildModel();
        }

        public void AddRoadWheelSet()
        {
            var wheels = blueprint.modules.Find(m => m != null && m.type == "WheelSet");
            if (wheels == null) blueprint.modules.Add(Part("WheelSet", Vector3.zero, Vector3.one, 20f, 720f, true));
            else wheels.massKg = Mathf.Min(1600f, wheels.massKg + 180f);
            RebuildModel();
        }

        public void SaveBlueprint()
        {
            try
            {
                string path = Path.Combine(Application.persistentDataPath, BlueprintFileName);
                File.WriteAllText(path, JsonUtility.ToJson(blueprint, true));
                Debug.Log("Blueprint saved to " + path);
            }
            catch (Exception ex) { Debug.LogError("Blueprint save failed: " + ex.Message); }
        }

        public bool LoadBlueprint()
        {
            try
            {
                string path = Path.Combine(Application.persistentDataPath, BlueprintFileName);
                if (!File.Exists(path)) return false;
                var loaded = JsonUtility.FromJson<TankBlueprint>(File.ReadAllText(path));
                if (loaded == null || loaded.schemaVersion != 1 || loaded.modules == null || loaded.modules.Count == 0) return false;
                blueprint = loaded;
                RebuildModel();
                return true;
            }
            catch (Exception ex) { Debug.LogError("Blueprint load failed: " + ex.Message); return false; }
        }

        public float ArmorAtWorldPoint(Vector3 point)
        {
            Vector3 local = transform.InverseTransformPoint(point);
            if (local.y > 0.55f) return blueprint.turretArmorMm;
            if (local.z > 0.8f) return blueprint.frontArmorMm;
            if (local.z < -0.8f) return blueprint.rearArmorMm;
            return blueprint.sideArmorMm;
        }

        public static float EstimatePenetrationMm(float projectileSpeedMps, float caliberMm)
        {
            // Intentionally game-tuned estimate, not a real-world armor calculation.
            return Mathf.Clamp(caliberMm * 0.8f * Mathf.Sqrt(Mathf.Max(1f, projectileSpeedMps) / 300f), 1f, 260f);
        }
    }
}
