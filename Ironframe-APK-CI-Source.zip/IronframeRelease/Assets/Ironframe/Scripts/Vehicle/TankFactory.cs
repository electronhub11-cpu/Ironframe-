using UnityEngine;

namespace Ironframe
{
    public static class TankFactory
    {
        public static TankController CreateTank(string objectName, Vector3 position, Quaternion rotation, bool localPlayer, bool addAI)
        {
            var root = new GameObject(objectName);
            root.transform.SetPositionAndRotation(position, rotation);
            var body = root.AddComponent<Rigidbody>();
            body.mass = 18000f;
            body.drag = 0.08f;
            body.angularDrag = 4.5f;
            body.useGravity = true;
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.Continuous;
            body.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

            var collider = root.AddComponent<BoxCollider>();
            collider.center = new Vector3(0f, 0.0f, 0f);
            collider.size = new Vector3(2.8f, 0.9f, 4.0f);

            var build = root.AddComponent<TankBuildController>();
            build.InitializeDefault();
            root.AddComponent<TankDamage>();
            var controller = root.AddComponent<TankController>();
            controller.IsLocalPlayer = localPlayer;
            root.AddComponent<TankAudio>();
            if (addAI)
            {
                var ai = root.AddComponent<TankAIController>();
                ai.enabled = true;
            }
            return controller;
        }
    }
}
