using UnityEngine;

namespace Ironframe
{
    public enum IronframeMode
    {
        TestRange = 0,
        Sandbox = 1,
        Mission = 2
    }

    public sealed class IronframeGameMode : MonoBehaviour
    {
        private TankController _player;
        private TankController _target;
        private TankAIController _targetAI;
        private float _missionSeconds;
        private bool _missionFinished;

        public IronframeMode Mode { get; private set; } = IronframeMode.TestRange;
        public string ObjectiveStatus { get; private set; } = "Objective: destroy the hostile vehicle";
        public float MissionSecondsRemaining => Mathf.Max(0f, _missionSeconds);

        public void Initialize(TankController player, TankController target)
        {
            if (_target != null && _target.Damage != null) _target.Damage.Destroyed -= OnTargetDestroyed;
            if (_player != null && _player.Damage != null) _player.Damage.Destroyed -= OnPlayerDestroyed;
            _player = player;
            _target = target;
            _targetAI = target != null ? target.GetComponent<TankAIController>() : null;
            if (_target != null && _target.Damage != null) _target.Damage.Destroyed += OnTargetDestroyed;
            if (_player != null && _player.Damage != null) _player.Damage.Destroyed += OnPlayerDestroyed;
            SetMode(IronframeMode.TestRange);
        }

        public void CycleMode()
        {
            SetMode((IronframeMode)(((int)Mode + 1) % 3));
        }

        public void SetMode(IronframeMode mode)
        {
            Mode = mode;
            _missionFinished = false;
            _missionSeconds = 180f;
            if (_targetAI != null)
            {
                bool clientOwnsNoAI = LanSessionManager.Instance != null && LanSessionManager.Instance.IsClient;
                _targetAI.enabled = mode != IronframeMode.Sandbox && !clientOwnsNoAI;
            }
            switch (Mode)
            {
                case IronframeMode.TestRange:
                    ObjectiveStatus = "TEST RANGE: engage the hostile target";
                    break;
                case IronframeMode.Sandbox:
                    ObjectiveStatus = "SANDBOX: target AI disabled; experiment with your build";
                    break;
                case IronframeMode.Mission:
                    ObjectiveStatus = "MISSION: destroy the hostile vehicle within 3:00";
                    break;
            }
        }

        public void ResetMission()
        {
            _missionFinished = false;
            _missionSeconds = 180f;
            if (Mode == IronframeMode.Mission) ObjectiveStatus = "MISSION: destroy the hostile vehicle within 3:00";
        }

        private void Update()
        {
            if (Mode != IronframeMode.Mission || _missionFinished) return;
            _missionSeconds -= Time.deltaTime;
            if (_missionSeconds <= 0f)
            {
                _missionSeconds = 0f;
                _missionFinished = true;
                ObjectiveStatus = "MISSION FAILED: time expired. Press RESET to retry.";
            }
        }

        private void OnTargetDestroyed(TankDamage target)
        {
            if (Mode == IronframeMode.Mission && !_missionFinished)
            {
                _missionFinished = true;
                ObjectiveStatus = "MISSION COMPLETE: hostile vehicle destroyed. Press RESET to replay.";
            }
            else if (Mode == IronframeMode.TestRange) ObjectiveStatus = "Target destroyed. Press RESET to respawn it.";
        }

        private void OnPlayerDestroyed(TankDamage player)
        {
            if (Mode == IronframeMode.Mission && !_missionFinished)
            {
                _missionFinished = true;
                ObjectiveStatus = "MISSION FAILED: vehicle disabled. Press RESET to retry.";
            }
        }
    }
}
