using UnityEngine;

namespace Ironframe
{
    /// <summary>Creates the original blockout test range and wires the playable prototype.</summary>
    public sealed class IronframeBootstrap : MonoBehaviour
    {
        [SerializeField] private bool createDemoArena = true;
        private static Material _groundMaterial;
        private static Material _coverMaterial;

        private void Awake()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            if (createDemoArena && GameObject.Find("IF_ArenaFloor") == null) CreateArena();
        }

        private static void CreateArena()
        {
            var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "IF_ArenaFloor";
            floor.transform.position = new Vector3(0f, -0.5f, 15f);
            floor.transform.localScale = new Vector3(110f, 1f, 110f);
            _groundMaterial = Resources.Load<Material>("Ironframe/Materials/IF_Ground");
            if (_groundMaterial == null) _groundMaterial = MakeMaterial(new Color(0.24f, 0.28f, 0.24f));
            floor.GetComponent<Renderer>().sharedMaterial = _groundMaterial;
            floor.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;

            CreateCover(new Vector3(-10f, 0.8f, 15f), new Vector3(1.4f, 1.6f, 5f));
            CreateCover(new Vector3(12f, 0.7f, 7f), new Vector3(4f, 1.4f, 1.5f));
            CreateCover(new Vector3(-13f, 0.6f, 34f), new Vector3(3f, 1.2f, 2f));
            CreateCover(new Vector3(15f, 0.6f, 34f), new Vector3(3f, 1.2f, 2f));

            var player = TankFactory.CreateTank("IF_PlayerVehicle", new Vector3(0f, 0.55f, 0f), Quaternion.identity, true, false);
            var enemy = TankFactory.CreateTank("IF_AI_Target", new Vector3(3f, 0.55f, 24f), Quaternion.Euler(0f, 180f, 0f), false, true);

            var cameraObject = new GameObject("IF_FollowCamera");
            var camera = cameraObject.AddComponent<Camera>();
            cameraObject.tag = "MainCamera";
            camera.fieldOfView = 64f;
            camera.nearClipPlane = 0.1f;
            camera.farClipPlane = 180f;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.14f, 0.18f, 0.17f);
            camera.allowHDR = false;
            camera.allowMSAA = false;
            camera.allowDynamicResolution = SystemInfo.supportsDynamicResolution;
            cameraObject.AddComponent<MobileDynamicResolutionController>();
            cameraObject.AddComponent<AudioListener>();
            var follow = cameraObject.AddComponent<TankCameraFollow>();
            follow.target = player.transform;
            cameraObject.transform.position = new Vector3(0f, 6f, -9f);
            cameraObject.transform.LookAt(player.transform.position + Vector3.up);

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.48f, 0.50f, 0.47f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.43f, 0.46f, 0.43f);
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 45f;
            RenderSettings.fogEndDistance = 125f;


            var networkObject = new GameObject("IronframeLAN");
            var lan = networkObject.AddComponent<LanSessionManager>();
            lan.Initialize(player);
            lan.RegisterAIActor(enemy);

            var modeObject = new GameObject("IronframeGameMode");
            var gameMode = modeObject.AddComponent<IronframeGameMode>();
            gameMode.Initialize(player, enemy);

            var uiObject = new GameObject("IronframeUI");
            var ui = uiObject.AddComponent<IronframeUI>();
            ui.Initialize(player, enemy, lan, gameMode);
        }

        private static void CreateCover(Vector3 position, Vector3 scale)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "IF_RangeCover";
            go.transform.position = position;
            go.transform.localScale = scale;
            if (_coverMaterial == null)
            {
                _coverMaterial = Resources.Load<Material>("Ironframe/Materials/IF_Cover");
                if (_coverMaterial == null) _coverMaterial = MakeMaterial(new Color(0.32f, 0.34f, 0.29f));
            }
            go.GetComponent<Renderer>().sharedMaterial = _coverMaterial;
            go.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            go.GetComponent<Renderer>().receiveShadows = false;
        }

        private static Material MakeMaterial(Color color)
        {
            var shader = Shader.Find("Universal Render Pipeline/Unlit");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            return new Material(shader) { color = color, enableInstancing = true };
        }
    }
}
