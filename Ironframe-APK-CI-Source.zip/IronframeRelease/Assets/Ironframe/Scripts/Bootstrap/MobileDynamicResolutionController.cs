using UnityEngine;
using UnityEngine.Rendering;

namespace Ironframe
{
    /// <summary>
    /// Lightweight adaptive render-scale controller. It adjusts buffer scale slowly to avoid
    /// reacting to isolated frame spikes. It is inactive when the platform lacks dynamic-resolution support.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MobileDynamicResolutionController : MonoBehaviour
    {
        [SerializeField, Range(0.7f, 1f)] private float minimumScale = 0.7f;
        [SerializeField, Range(0.7f, 1f)] private float maximumScale = 1f;
        [SerializeField] private float downscaleThresholdMs = 18.5f;
        [SerializeField] private float upscaleThresholdMs = 17.2f;
        [SerializeField] private bool adaptive = true;

        private float _scale = 1f;
        private float _sampleElapsed;
        private float _frameTimeSum;
        private int _sampleCount;
        private float _slowWindowSeconds;
        private float _goodWindowSeconds;

        public float CurrentScale => _scale;
        public bool AdaptiveEnabled => adaptive;
        public bool Supported => SystemInfo.supportsDynamicResolution;

        private void Awake()
        {
            minimumScale = Mathf.Clamp(minimumScale, 0.7f, 1f);
            maximumScale = Mathf.Clamp(maximumScale, minimumScale, 1f);
            ApplyScale();
        }

        private void Update()
        {
            if (!adaptive || !Supported) return;
            _sampleElapsed += Time.unscaledDeltaTime;
            _frameTimeSum += Time.unscaledDeltaTime * 1000f;
            _sampleCount++;
            if (_sampleElapsed < 0.75f || _sampleCount == 0) return;

            float averageMs = _frameTimeSum / _sampleCount;
            float elapsed = _sampleElapsed;
            _sampleElapsed = 0f;
            _frameTimeSum = 0f;
            _sampleCount = 0;

            if (averageMs > downscaleThresholdMs)
            {
                _slowWindowSeconds += elapsed;
                _goodWindowSeconds = 0f;
                if (_slowWindowSeconds >= 1.5f && _scale > minimumScale)
                {
                    _scale = Mathf.Max(minimumScale, _scale - 0.05f);
                    _slowWindowSeconds = 0f;
                    ApplyScale();
                }
            }
            else if (averageMs < upscaleThresholdMs)
            {
                _goodWindowSeconds += elapsed;
                _slowWindowSeconds = 0f;
                if (_goodWindowSeconds >= 2.25f && _scale < maximumScale)
                {
                    _scale = Mathf.Min(maximumScale, _scale + 0.025f);
                    _goodWindowSeconds = 0f;
                    ApplyScale();
                }
            }
            else
            {
                _slowWindowSeconds = 0f;
                _goodWindowSeconds = 0f;
            }
        }

        public void SetFixedScale(float scale)
        {
            adaptive = false;
            _scale = Mathf.Clamp(scale, 0.7f, 1f);
            ApplyScale();
        }

        public void EnableAdaptive()
        {
            adaptive = true;
            _scale = Mathf.Clamp(_scale, minimumScale, maximumScale);
            _slowWindowSeconds = 0f;
            _goodWindowSeconds = 0f;
            ApplyScale();
        }

        private void ApplyScale()
        {
            bool supported = Supported;
            foreach (var camera in Camera.allCameras) camera.allowDynamicResolution = supported;
            if (supported) ScalableBufferManager.ResizeBuffers(_scale, _scale);
        }
    }
}
