using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Profiling;

namespace Ironframe
{
    /// <summary>Resolution-independent IMGUI controls kept deliberately package-light for the prototype.</summary>
    public sealed class IronframeUI : MonoBehaviour
    {
        private TankController _player;
        private TankController _enemy;
        private LanSessionManager _lan;
        private IronframeGameMode _gameMode;
        private MobileDynamicResolutionController _resolutionScaler;
        private bool _showBuild;
        private bool _showNetwork;
        private bool _showSettings;
        private string _hostAddress = "192.168.1.1";
        private string _notice = "Build a vehicle, then test it against the red target.";
        private float _noticeTimer;
        private int _quality = 1;
        private readonly float[] _frameTimes = new float[45];
        private int _frameIndex;
        private int _frameSamples;
        private GUIStyle _smallLabel;
        private GUIStyle _header;
        private GUIStyle _button;
        private GUIStyle _box;

        private void Update()
        {
            _frameTimes[_frameIndex] = Mathf.Max(0.0001f, Time.unscaledDeltaTime);
            _frameIndex = (_frameIndex + 1) % _frameTimes.Length;
            _frameSamples = Mathf.Min(_frameSamples + 1, _frameTimes.Length);
        }

        public void Initialize(TankController player, TankController enemy, LanSessionManager lan, IronframeGameMode gameMode)
        {
            _player = player;
            _enemy = enemy;
            _lan = lan;
            _gameMode = gameMode;
            _resolutionScaler = FindObjectOfType<MobileDynamicResolutionController>();
        }

        private void OnGUI()
        {
            if (_player == null || _player.Build == null) return;
            float scale = Mathf.Max(0.5f, Screen.height / 720f);
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1f));
            float width = Screen.width / scale;
            const float height = 720f;
            InitStyles();

            GUI.Box(new Rect(14, 12, 470, 114), GUIContent.none, _box);
            GUI.Label(new Rect(28, 20, 340, 28), "IRONFRAME  /  FIELD TEST", _header);
            string health = _player.Damage != null ? _player.Damage.Health.ToString("0") : "--";
            string engine = _player.Damage != null ? Mathf.RoundToInt(_player.Damage.EngineCondition * 100f).ToString() : "--";
            GUI.Label(new Rect(28, 52, 340, 24), "HULL " + health + "%    ENGINE " + engine + "%    SPEED " + (_player.CurrentSpeedMps * 3.6f).ToString("0") + " km/h", _smallLabel);
            if (_noticeTimer > 0f) _noticeTimer -= Time.unscaledDeltaTime;
            string status = _noticeTimer > 0f ? _notice : (_lan != null ? _lan.Status : "Offline");
            GUI.Label(new Rect(28, 78, 430, 22), status, _smallLabel);
            if (_gameMode != null)
            {
                string objective = _gameMode.ObjectiveStatus;
                if (_gameMode.Mode == IronframeMode.Mission && _gameMode.MissionSecondsRemaining > 0f && !_gameMode.ObjectiveStatus.Contains("COMPLETE") && !_gameMode.ObjectiveStatus.Contains("FAILED"))
                    objective += "  [" + Mathf.FloorToInt(_gameMode.MissionSecondsRemaining / 60f).ToString("0") + ":" + Mathf.FloorToInt(_gameMode.MissionSecondsRemaining % 60f).ToString("00") + "]";
                GUI.Label(new Rect(500, 52, 570, 26), objective, _smallLabel);
            }
            float average = 0f;
            for (int i = 0; i < _frameSamples; i++) average += _frameTimes[i];
            average = _frameSamples > 0 ? average / _frameSamples : 0f;
            float fps = average > 0f ? 1f / average : 0f;
            GUI.Label(new Rect(28, 100, 430, 22), "FPS " + fps.ToString("0") + "   Frame " + (average * 1000f).ToString("0.0") + " ms   Unity alloc " + (Profiler.GetTotalAllocatedMemoryLong() / (1024f * 1024f)).ToString("0") + " MB", _smallLabel);

            float topX = width - 535f;
            if (GUI.Button(new Rect(topX, 14, 92, 44), "BUILD", _button)) { _showBuild = !_showBuild; _showNetwork = false; _showSettings = false; }
            if (GUI.Button(new Rect(topX + 98, 14, 100, 44), "LAN PLAY", _button)) { _showNetwork = !_showNetwork; _showBuild = false; _showSettings = false; }
            if (GUI.Button(new Rect(topX + 204, 14, 92, 44), "MODE", _button)) { if (_gameMode != null) _gameMode.CycleMode(); }
            if (GUI.Button(new Rect(topX + 302, 14, 105, 44), "SETTINGS", _button)) { _showSettings = !_showSettings; _showBuild = false; _showNetwork = false; }
            if (GUI.Button(new Rect(topX + 413, 14, 92, 44), "RESET", _button)) ResetArena();

            DrawDriveControls(width, height);
            DrawAimControls(width, height);
            if (_showBuild) DrawBuildPanel(width);
            if (_showNetwork) DrawNetworkPanel(width);
            if (_showSettings) DrawSettingsPanel(width);
        }

        private void DrawDriveControls(float width, float height)
        {
            GUI.Box(new Rect(18, height - 188, 410, 170), GUIContent.none, _box);
            float throttle = 0f, steer = 0f;
            if (GUI.RepeatButton(new Rect(30, height - 174, 128, 70), "FORWARD ▲", _button)) throttle += 1f;
            if (GUI.RepeatButton(new Rect(30, height - 94, 128, 70), "REVERSE ▼", _button)) throttle -= 1f;
            if (GUI.RepeatButton(new Rect(172, height - 132, 112, 70), "◀ TURN", _button)) steer -= 1f;
            if (GUI.RepeatButton(new Rect(296, height - 132, 112, 70), "TURN ▶", _button)) steer += 1f;
            _player.SetDriveInput(throttle, steer);
        }

        private void DrawAimControls(float width, float height)
        {
            GUI.Box(new Rect(width - 428, height - 188, 410, 170), GUIContent.none, _box);
            float yaw = 0f, pitch = 0f;
            if (GUI.RepeatButton(new Rect(width - 414, height - 132, 94, 70), "AIM ◀", _button)) yaw -= 1f;
            if (GUI.RepeatButton(new Rect(width - 312, height - 132, 94, 70), "AIM ▶", _button)) yaw += 1f;
            if (GUI.RepeatButton(new Rect(width - 210, height - 132, 88, 70), "ELEV ▲", _button)) pitch += 1f;
            if (GUI.RepeatButton(new Rect(width - 114, height - 132, 88, 70), "LOWER ▼", _button)) pitch -= 1f;
            bool fire = GUI.RepeatButton(new Rect(width - 155, height - 72, 137, 55), "FIRE", _button);
            _player.SetAimInput(yaw, pitch);
            _player.SetFireHeld(fire);
        }

        private void DrawBuildPanel(float width)
        {
            var b = _player.Build;
            float x = width - 410f;
            GUI.Box(new Rect(x, 70, 390, 590), GUIContent.none, _box);
            GUI.Label(new Rect(x + 16, 82, 350, 34), "GARAGE / MODULAR CONFIGURATION", _header);
            GUI.Label(new Rect(x + 16, 116, 350, 44), "Mass: " + (b.TotalMassKg / 1000f).ToString("0.0") + " t    COM: " + b.LocalCenterOfMass.ToString("F2"), _smallLabel);
            GUI.Label(new Rect(x + 16, 151, 350, 28), "Frontal armor: " + b.Blueprint.frontArmorMm.ToString("0") + " mm", _smallLabel);
            GUI.Label(new Rect(x + 16, 176, 350, 28), "Estimated 75 mm penetration @ 600 m/s: " + TankBuildController.EstimatePenetrationMm(600f, 75f).ToString("0") + " mm", _smallLabel);

            if (GUI.Button(new Rect(x + 16, 212, 170, 46), "FRONT ARMOR +10", _button)) { b.AdjustArmor(10f); Notice("Front / side armor increased."); }
            if (GUI.Button(new Rect(x + 196, 212, 170, 46), "FRONT ARMOR -10", _button)) { b.AdjustArmor(-10f); Notice("Front / side armor reduced."); }
            if (GUI.Button(new Rect(x + 16, 266, 170, 46), "ADD ARMOR PLATE", _button)) { b.AddArmorPlate(); Notice("Added an attachable armor plate."); }
            if (GUI.Button(new Rect(x + 196, 266, 170, 46), "ADD ROAD WHEELS", _button)) { b.AddRoadWheelSet(); Notice("Updated the road-wheel module."); }
            if (GUI.Button(new Rect(x + 16, 320, 170, 46), "ADD SMOKE PODS", _button)) { b.AddSmokeLaunchers(); Notice("Smoke launcher modules attached."); }
            if (GUI.Button(new Rect(x + 196, 320, 170, 46), "ADD FUEL POD", _button)) { b.AddExternalFuel(); Notice("External fuel module attached."); }
            if (GUI.Button(new Rect(x + 16, 374, 170, 46), "TURRET -15°", _button)) { b.RotateTurretOffset(-15f); Notice("Turret mount rotated."); }
            if (GUI.Button(new Rect(x + 196, 374, 170, 46), "TURRET +15°", _button)) { b.RotateTurretOffset(15f); Notice("Turret mount rotated."); }
            if (GUI.Button(new Rect(x + 16, 428, 170, 46), "SAVE BLUEPRINT", _button)) { b.SaveBlueprint(); Notice("Blueprint saved locally."); }
            if (GUI.Button(new Rect(x + 196, 428, 170, 46), "LOAD BLUEPRINT", _button)) Notice(b.LoadBlueprint() ? "Blueprint loaded." : "No valid saved blueprint found.");
            if (GUI.Button(new Rect(x + 16, 482, 170, 42), "SNAP TURRET ◀", _button)) b.MoveTurretSnap(new Vector3(-0.25f, 0f, 0f));
            if (GUI.Button(new Rect(x + 196, 482, 170, 42), "SNAP TURRET ▶", _button)) b.MoveTurretSnap(new Vector3(0.25f, 0f, 0f));
            if (GUI.Button(new Rect(x + 16, 530, 170, 42), "SNAP TURRET FWD", _button)) b.MoveTurretSnap(new Vector3(0f, 0f, 0.25f));
            if (GUI.Button(new Rect(x + 196, 530, 170, 42), "REMOVE LAST ADDON", _button)) b.RemoveLastAddon();
        }

        private void DrawNetworkPanel(float width)
        {
            float x = width - 480f;
            GUI.Box(new Rect(x, 70, 460, 290), GUIContent.none, _box);
            GUI.Label(new Rect(x + 16, 82, 420, 34), "LOCAL NETWORK / WI-FI HOTSPOT", _header);
            GUI.Label(new Rect(x + 16, 118, 420, 44), "Host address: " + (_lan != null ? _lan.GetLocalIPv4Address() : "--") + "    UDP " + LanSessionManager.Port, _smallLabel);
            GUI.Label(new Rect(x + 16, 146, 420, 26), "Joiner's host IPv4 address:", _smallLabel);
            _hostAddress = GUI.TextField(new Rect(x + 16, 172, 240, 42), _hostAddress, _button);
            if (GUI.Button(new Rect(x + 266, 172, 170, 42), "HOST SESSION", _button))
            {
                if (_lan != null) _lan.StartHost();
                Notice(_lan != null ? _lan.Status : "LAN manager unavailable");
            }
            if (GUI.Button(new Rect(x + 16, 222, 204, 44), "JOIN HOST", _button))
            {
                if (_lan != null) _lan.StartClient(_hostAddress);
                Notice(_lan != null ? _lan.Status : "LAN manager unavailable");
            }
            if (GUI.Button(new Rect(x + 230, 222, 206, 44), "DISCONNECT", _button))
            {
                if (_lan != null) _lan.StopSession();
                Notice("Disconnected from LAN session.");
            }
            GUI.Label(new Rect(x + 16, 272, 422, 66), _lan != null ? _lan.Status : "Offline", _smallLabel);
        }

        private void DrawSettingsPanel(float width)
        {
            float x = width - 330f;
            GUI.Box(new Rect(x, 70, 310, 340), GUIContent.none, _box);
            GUI.Label(new Rect(x + 16, 82, 275, 32), "PERFORMANCE SETTINGS", _header);
            if (GUI.Button(new Rect(x + 16, 124, 278, 42), "LOW / 70% RENDER SCALE", _button)) ApplyQuality(0);
            if (GUI.Button(new Rect(x + 16, 172, 278, 42), "MEDIUM / 85% SCALE", _button)) ApplyQuality(1);
            if (GUI.Button(new Rect(x + 16, 220, 278, 42), "HIGH / 100% SCALE", _button)) ApplyQuality(2);
            if (GUI.Button(new Rect(x + 16, 268, 278, 42), "AUTO / ADAPT 70–100%", _button))
            {
                if (_resolutionScaler != null && _resolutionScaler.Supported)
                {
                    _resolutionScaler.EnableAdaptive();
                    Notice("Adaptive render scaling enabled.");
                }
                else Notice("Adaptive render scaling is unsupported on this device.");
            }
            string scalerStatus = _resolutionScaler == null ? "Scaler unavailable" :
                (_resolutionScaler.Supported ? (_resolutionScaler.AdaptiveEnabled ? "AUTO" : "MANUAL") + " scale " + (_resolutionScaler.CurrentScale * 100f).ToString("0") + "%" : "Dynamic resolution unsupported");
            GUI.Label(new Rect(x + 16, 315, 278, 52), scalerStatus + "\n30 FPS minimum target / 60 FPS goal. Verify on device.", _smallLabel);
        }

        private void ApplyQuality(int level)
        {
            _quality = Mathf.Clamp(level, 0, 2);
            if (QualitySettings.names.Length > _quality) QualitySettings.SetQualityLevel(_quality, true);
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = 60;
            QualitySettings.shadowDistance = 0f;
            QualitySettings.shadowResolution = ShadowResolution.Low;
            QualitySettings.lodBias = _quality == 0 ? 0.65f : (_quality == 1 ? 0.85f : 1.0f);
            QualitySettings.maximumLODLevel = _quality == 0 ? 1 : 0;
            QualitySettings.antiAliasing = _quality == 2 ? 2 : 0;
            float scale = _quality == 0 ? 0.70f : (_quality == 1 ? 0.85f : 1f);
            bool supported = SystemInfo.supportsDynamicResolution;
            if (_resolutionScaler != null) _resolutionScaler.SetFixedScale(scale);
            else if (supported) ScalableBufferManager.ResizeBuffers(scale, scale);
            foreach (var camera in Camera.allCameras)
            {
                camera.allowDynamicResolution = supported;
                camera.allowMSAA = _quality == 2;
            }
            string preset = _quality == 0 ? "Low" : (_quality == 1 ? "Medium" : "High");
            Notice(supported ? preset + " preset applied at " + (scale * 100f).ToString("0") + "% scale." : preset + " preset applied; dynamic render scale unsupported on this device.");
        }

        private void ResetArena()
        {
            if (_lan != null && _lan.IsClient)
            {
                Notice("Only the host can reset a network session.");
                return;
            }
            if (_player != null && _player.Damage != null) _player.Damage.ResetDamage();
            if (_enemy != null && _enemy.Damage != null)
            {
                _enemy.Damage.ResetDamage();
                _enemy.transform.position = new Vector3(3f, 0.55f, 24f);
                _enemy.transform.rotation = Quaternion.Euler(0f, 180f, 0f);
                if (_enemy.Body != null) { _enemy.Body.isKinematic = false; _enemy.Body.velocity = Vector3.zero; _enemy.Body.angularVelocity = Vector3.zero; }
                var enemyCollider = _enemy.GetComponent<Collider>(); if (enemyCollider != null) enemyCollider.enabled = true;
            }
            if (_player != null)
            {
                _player.transform.position = new Vector3(0f, 0.55f, 0f);
                _player.transform.rotation = Quaternion.identity;
                if (_player.Body != null) { _player.Body.isKinematic = false; _player.Body.velocity = Vector3.zero; _player.Body.angularVelocity = Vector3.zero; }
                var playerCollider = _player.GetComponent<Collider>(); if (playerCollider != null) playerCollider.enabled = true;
            }
            if (_lan != null && _lan.IsHost) _lan.ResetRemotePlayers();
            if (_gameMode != null) _gameMode.ResetMission();
            Notice(_lan != null && _lan.IsHost ? "Test range and network players reset." : "Test range reset.");
        }

        private void Notice(string text)
        {
            _notice = text;
            _noticeTimer = 3f;
        }

        private void InitStyles()
        {
            if (_button != null) return;
            _button = new GUIStyle(GUI.skin.button) { fontSize = 19, fontStyle = FontStyle.Bold, wordWrap = true, alignment = TextAnchor.MiddleCenter };
            _smallLabel = new GUIStyle(GUI.skin.label) { fontSize = 18, wordWrap = true, normal = { textColor = new Color(0.83f, 0.88f, 0.83f) } };
            _header = new GUIStyle(GUI.skin.label) { fontSize = 23, fontStyle = FontStyle.Bold, normal = { textColor = new Color(0.93f, 0.79f, 0.43f) } };
            _box = new GUIStyle(GUI.skin.box) { normal = { background = MakeSolidTexture(new Color(0.035f, 0.055f, 0.047f, 0.88f) ) } };
        }

        private static Texture2D MakeSolidTexture(Color color)
        {
            var texture = new Texture2D(1, 1, TextureFormat.RGBA32, false) { hideFlags = HideFlags.HideAndDontSave };
            texture.SetPixel(0, 0, color); texture.Apply(false, true); return texture;
        }
    }
}
