using System;
using UnityEngine;

namespace Ironframe
{
    /// <summary>Procedurally synthesized placeholder sounds; no third-party audio assets.</summary>
    public sealed class TankAudio : MonoBehaviour
    {
        private static AudioClip _engineClip;
        private static AudioClip _shotClip;
        private AudioSource _engineSource;
        private AudioSource _shotSource;
        private TankController _tank;

        private void Awake()
        {
            BuildClips();
            _tank = GetComponent<TankController>();
            _engineSource = gameObject.AddComponent<AudioSource>();
            _engineSource.clip = _engineClip;
            _engineSource.loop = true;
            _engineSource.playOnAwake = false;
            _engineSource.spatialBlend = 1f;
            _engineSource.volume = 0.22f;
            _engineSource.minDistance = 5f;
            _engineSource.maxDistance = 45f;
            _engineSource.dopplerLevel = 0f;
            _engineSource.Play();

            _shotSource = gameObject.AddComponent<AudioSource>();
            _shotSource.playOnAwake = false;
            _shotSource.spatialBlend = 1f;
            _shotSource.volume = 0.5f;
            _shotSource.minDistance = 8f;
            _shotSource.maxDistance = 75f;
            _shotSource.dopplerLevel = 0f;
        }

        private void OnEnable()
        {
            if (_tank != null) _tank.Fired += OnFired;
        }

        private void OnDisable()
        {
            if (_tank != null) _tank.Fired -= OnFired;
        }

        private void Update()
        {
            if (_engineSource != null && _tank != null)
                _engineSource.pitch = Mathf.Lerp(0.78f, 1.35f, Mathf.Clamp01(_tank.CurrentSpeedMps / 9f));
        }

        private void OnFired(TankController tank, Vector3 origin, Vector3 direction, float speed, float caliber, float damage)
        {
            PlayReplicatedShot();
        }

        public void PlayReplicatedShot()
        {
            if (_shotSource != null && _shotClip != null) _shotSource.PlayOneShot(_shotClip);
        }

        private static void BuildClips()
        {
            if (_engineClip != null && _shotClip != null) return;
            const int rate = 22050;
            int engineSamples = rate / 2;
            float[] engine = new float[engineSamples];
            for (int i = 0; i < engine.Length; i++)
            {
                float t = (float)i / rate;
                float fundamental = Mathf.Sin(2f * Mathf.PI * 58f * t);
                float harmonic = Mathf.Sin(2f * Mathf.PI * 116f * t) * 0.35f;
                float pulse = Mathf.Sin(2f * Mathf.PI * 4f * t) * 0.12f + 0.88f;
                engine[i] = (fundamental * 0.19f + harmonic * 0.06f) * pulse;
            }
            _engineClip = AudioClip.Create("IF_Original_Engine_Loop", engine.Length, 1, rate, false);
            _engineClip.SetData(engine, 0);

            int shotSamples = rate / 5;
            float[] shot = new float[shotSamples];
            var random = new System.Random(621);
            for (int i = 0; i < shot.Length; i++)
            {
                float t = (float)i / shot.Length;
                float envelope = Mathf.Exp(-t * 13f) * (1f - Mathf.Clamp01(t * 1.3f));
                float noise = (float)(random.NextDouble() * 2.0 - 1.0);
                float low = Mathf.Sin(2f * Mathf.PI * 62f * i / rate) * 0.4f;
                shot[i] = (noise * 0.56f + low) * envelope * 0.85f;
            }
            _shotClip = AudioClip.Create("IF_Original_Gun_Report", shot.Length, 1, rate, false);
            _shotClip.SetData(shot, 0);
        }
    }
}
